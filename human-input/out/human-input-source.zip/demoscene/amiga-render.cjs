const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
(async()=>{
 const {ready,Paula,stringCall}=await import('./vendor/paula.js'),m=await ready;
 const license=stringCall(m,p=>m._openmpt_get_string(p),'license');fs.writeFileSync(path.join(__dirname,'vendor/LIBOPENMPT-LICENSE.txt'),m.UTF8ToString(license));m._openmpt_free_string(license);
 const out=path.join(__dirname,'out'),replay=new Paula(m,fs.readFileSync(path.join(out,'raster-ritual.mod'))),frames=Math.round(176.64*48000),l=new Float32Array(4096),r=new Float32Array(4096),raw=path.join(out,'paula.f32'),fd=fs.openSync(raw,'w');
 for(let base=0;base<frames;base+=4096){replay.read(l,r);const count=Math.min(4096,frames-base),b=Buffer.alloc(count*8);for(let i=0;i<count;i++){b.writeFloatLE(l[i],i*8);b.writeFloatLE(r[i],i*8+4)}fs.writeSync(fd,b)}
 fs.closeSync(fd);replay.destroy();const ff=require('./tools.cjs').ffmpeg;
 for(const args of [['-f','f32le','-ar','48000','-ac','2','-i',raw,'-c:a','pcm_s16le',path.join(out,'raster-ritual.wav')],['-i',path.join(out,'raster-ritual.wav'),'-c:a','aac','-b:a','256k',path.join(out,'raster-ritual.m4a')]]){const p=spawnSync(ff,['-y','-v','error',...args],{windowsHide:true,encoding:'utf8'});if(p.status!==0)throw Error(p.stderr)}
 fs.unlinkSync(raw);console.log('Paula / A500: rendered 176.64 seconds, 48 kHz stereo, shared live/offline signal path.');
})().catch(e=>{console.error(e);process.exitCode=1});
