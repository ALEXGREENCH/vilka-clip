// Clean original stereo soundtrack for the demo.
require('./mp3-music.cjs');
