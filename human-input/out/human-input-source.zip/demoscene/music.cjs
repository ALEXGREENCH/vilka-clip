// Original four-channel score. Pitch, voicings and strong beats are explicit and audited.
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),theme=require('./theme');
const DIR=__dirname,OUT=path.join(DIR,'out'),SR=7093789.2/(2*214),TAU=Math.PI*2;
fs.mkdirSync(OUT,{recursive:true});let seed=20261003;
const noise=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/2147483648-1};
const hz=m=>440*2**((m-69)/12),sin=(f,t)=>Math.sin(TAU*f*t),tri=(f,t)=>2/Math.PI*Math.asin(sin(f,t));
function pulse(f,t){let v=0;for(let h=1;h<=5;h++)v+=Math.sin(Math.PI*h*.25)*Math.cos(TAU*f*h*t-Math.PI*h*.25)/h;return v*.8}
const samples=[];
function add(name,seconds,fn,baseMidi=null,notes=null){
 const n=Math.min(65532,Math.floor(seconds*SR/2)*2),raw=new Float32Array(n);let peak=0;
 for(let i=0;i<n;i++){const v=fn(i/SR)*Math.min(1,i/38,(n-i)/140);raw[i]=v;peak=Math.max(peak,Math.abs(v))}
 const data=Buffer.alloc(n),gain=peak>.94?.94/peak:1;
 for(let i=0;i<n;i++)data.writeInt8(Math.round(raw[i]*gain*125),i);
 samples.push({name,data,volume:48,baseMidi,notes});return samples.length;
}
const kick=t=>Math.tanh(sin(1,52*t+3.3*(1-Math.exp(-t*65)))*1.35)*.83*Math.exp(-t*12)+noise()*.08*Math.exp(-t*250);
const snare=t=>(noise()*.64+sin(190,t)*.2)*Math.exp(-t*24);
const hat=t=>noise()*.26*Math.exp(-t*80);
const K=add('01 PUNCH KICK',.32,kick),S=add('02 DRY SNARE',.23,snare),H=add('03 CLOSED HAT',.09,hat),O=add('04 OPEN HAT',.24,t=>noise()*.24*Math.exp(-t*18));
const KS=add('05 KICK + SNARE',.34,t=>(kick(t)+snare(t)*.9)*.82);
const B=add('06 C3 ROUND BASS',.65,t=>(tri(hz(48),t)*.65+pulse(hz(48),t)*.32)*Math.exp(-t*8),48);
const L=add('07 C5 NEON LEAD',1.85,t=>(pulse(hz(72),t)*.24+tri(hz(72),t)*.26+sin(hz(72),t)*.43)*Math.min(1,t*70)*Math.exp(-t*1.8),72);
const A=add('08 C5 GLASS ARP',.7,t=>(sin(hz(72),t)*.64+sin(hz(84),t)*.13+sin(hz(72)*3,t)*.04)*Math.exp(-t*9),72);
const chords=[
 {name:'Am',root:45,pcs:[9,0,4],voices:[57,60,64]},
 {name:'F/A',root:41,pcs:[5,9,0],voices:[57,60,65]},
 {name:'C/G',root:48,pcs:[0,4,7],voices:[55,60,64]},
 {name:'Em/G',root:40,pcs:[4,7,11],voices:[55,59,64]},
 {name:'Dm/A',root:38,pcs:[2,5,9],voices:[57,62,65]}
];
for(const chord of chords)chord.sample=add('VOICED '+chord.name,1.88,t=>chord.voices.reduce((v,m)=>v+sin(hz(m),t)*.17+tri(hz(m),t)*.09+pulse(hz(m),t)*.025*Math.min(1,t*3),0)*Math.min(1,t*13)*Math.exp(-t*.60),null,chord.voices);
const CR=add('0E KICK + CYMBAL',.65,t=>kick(t)+noise()*.12*Math.exp(-t*8));
const TOM=add('0F LOW TOM',.24,t=>sin(110,t)*.64*Math.exp(-t*18));
const BL=add('10 C5 SOFT BELL',1.5,t=>(sin(hz(72),t)*.64+sin(hz(84),t)*.10*Math.exp(-t*8))*Math.exp(-t*2.8),72);
const periods=[856,808,762,720,678,640,604,570,538,508,480,453,428,404,381,360,339,320,302,285,269,254,240,226,214,202,190,180,170,160,151,143,135,127,120,113];
const pat=[],names=theme.chapters.map(c=>c.name),harmonyAudit=[];
const motifs=[
 [[0,69],[6,76],[8,72],[14,71]],
 [[0,69],[6,72],[8,77],[12,72],[14,69]],
 [[0,67],[4,72],[8,76],[12,72]],
 [[0,71],[6,67],[8,64],[12,67],[14,71]],
 [[0,69],[4,74],[8,77],[12,74],[14,72]]
];
const empty=()=>({sample:0,note:null,midi:null,period:0,fx:0,param:0});
function put(rows,row,ch,sample,midi,volume){
 const instrument=samples[sample-1],note=instrument.baseMidi===null?24:24+midi-instrument.baseMidi;
 assert(note>=0&&note<36,'Instrument register exceeded; never silently clamp pitch');
 rows[row][ch]={sample,note,midi,period:periods[note],fx:0xC,param:volume};
 if(instrument.notes)rows[row][ch].voicing=instrument.notes;
}
for(let p=0;p<23;p++){
 const rows=Array.from({length:64},()=>Array.from({length:4},empty)),intro=p<2,quiet=p===14,build=p===15,peak=p>=16&&p<=20,outro=p===22;
 const progression=outro?[1,4,3,0]:quiet?[0,2,1,3]:(p>=8&&p<14)?[4,1,0,3]:[0,1,4,3];
 for(let bar=0;bar<4;bar++){
  const base=bar*16,ci=progression[bar],chord=chords[ci];
  harmonyAudit.push({pattern:p,bar,chord:chord.name,voicing:chord.voices,bass:chord.root});
  if(!quiet&&(!intro||p===1||bar>=2)){
   for(let step=0;step<16;step++){
    let drum=0,volume=0;
    if(step%4===0){drum=step%8===4?KS:K;volume=step%8===4?55:61}
    if(step%4===2){drum=O;volume=26}
    if(peak&&step%4===3){drum=H;volume=15}
    if([7,11].includes(p)&&step===6){drum=K;volume=47}
    if(outro){if(step%8===0){drum=K;volume=34-bar*5}else drum=0}
    if(build){drum=step%(bar<2?4:2)===0?S:0;volume=25+bar*7}
    if(drum)put(rows,base+step,0,drum,null,volume);
   }
   if(bar===3&&peak){put(rows,base+14,0,S,null,43);put(rows,base+15,0,TOM,null,34)}
  }
  const bassSteps=quiet||intro||outro?[0,8]:[2,6,10,14];
  for(const step of bassSteps)put(rows,base+step,1,B,chord.root,quiet?30:outro?34:46);
  // Pads and arps take turns in one voice, below the foreground melody.
  if(!intro&&!quiet&&!outro&&(p%2===0||build)){
   for(let n=0;n<8;n++)put(rows,base+n*2,2,A,chord.voices[[0,1,2,1,0,2,1,2][n]],n%4===0?23:18);
  }else put(rows,base,2,chord.sample,chord.voices[0],quiet?24:23);
  let melody=motifs[ci];
  if(intro||quiet||outro)melody=melody.filter(([step])=>step===0||step===8);
  if(outro&&bar===3)melody=[[0,72],[8,69]];
  for(const [step,midi]of melody){
   assert([0,2,4,5,7,9,11].includes(midi%12),'Non-diatonic melody');
   if(step%4===0)assert(chord.pcs.includes(midi%12),'Strong-beat melody outside chord');
   put(rows,base+step,3,intro||quiet||outro?BL:L,midi,quiet?29:peak?41:intro?30:37);
  }
  // Leave real rests at phrase endings, and apply small vibrato only to held notes.
  if(!quiet&&!outro&&bar%2===1){rows[base+15][3]={...empty(),fx:0xE,param:0xC0}}
  if(peak)for(const step of [2,6,10])if(!rows[base+step][3].period)rows[base+step][3]={...empty(),fx:0x4,param:0x21};
 }
 if(p===0){rows[0][0]={...empty(),fx:0xF,param:125};rows[0][1].fx=0xF;rows[0][1].param=6}
 if([2,6,8,16,18,20].includes(p))put(rows,0,0,CR,null,58);
 pat.push(rows);
}
// Audit the calibrated playback pitch against equal temperament (Paula periods are integers).
const pitchErrors=[];
for(const rows of pat)for(const row of rows)for(const cell of row){if(!cell.sample)continue;const s=samples[cell.sample-1];if(s.baseMidi!==null){const actual=hz(s.baseMidi)*214/cell.period,target=hz(cell.midi),cents=1200*Math.log2(actual/target);assert(Math.abs(cents)<8);pitchErrors.push(Math.abs(cents))}}
fs.writeFileSync(path.join(OUT,'music-audit.json'),JSON.stringify({key:'A natural minor / C major',tempo:125,meter:'4/4',sampleBases:'Explicit MIDI roots at period 214',maxPitchErrorCents:Math.max(...pitchErrors),melodyRange:'E4–F5',arpeggioRange:'G3–F4',bassRange:'D2–C3',strongBeats:'All melodic strong beats are chord tones',voicings:chords.map(c=>({name:c.name,midi:c.voices})),bars:harmonyAudit},null,2));
const header=Buffer.alloc(1084);header.write('HUMAN / INPUT',0,'ascii');
for(let i=0;i<31;i++){const s=samples[i],o=20+i*30;if(!s){header.writeUInt16BE(1,o+28);continue}header.write(s.name.slice(0,22),o,'ascii');header.writeUInt16BE(s.data.length/2,o+22);header[o+25]=s.volume;header.writeUInt16BE(0,o+26);header.writeUInt16BE(1,o+28)}
header[950]=23;header[951]=127;for(let i=0;i<23;i++)header[952+i]=i;header.write('M.K.',1080,'ascii');
const pdata=Buffer.alloc(23*1024);for(let p=0;p<23;p++)for(let r=0;r<64;r++)for(let ch=0;ch<4;ch++){const v=pat[p][r][ch],o=p*1024+r*16+ch*4;pdata[o]=(v.sample&0xf0)|((v.period>>8)&15);pdata[o+1]=v.period&255;pdata[o+2]=((v.sample&15)<<4)|v.fx;pdata[o+3]=v.param;}
const mod=Buffer.concat([header,pdata,...samples.map(s=>s.data)]);fs.writeFileSync(path.join(OUT,'raster-ritual.mod'),mod);
fs.writeFileSync(path.join(DIR,'score.json'),JSON.stringify({title:theme.title,version:'human-input-harmony5',bpm:125,speed:6,rowDuration:.12,patternDuration:7.68,duration:176.64,channels:4,sampleBits:8,samples:samples.map(s=>({name:s.name,bytes:s.data.length,baseMidi:s.baseMidi,voicing:s.notes})),names,patterns:pat}));
require('./amiga-render.cjs');
