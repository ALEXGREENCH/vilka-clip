// HUMAN / INPUT: original hard melodic four-channel chip score. No borrowed samples.
'use strict';
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
const DIR=__dirname,OUT=path.join(DIR,'out'),theme=require('./theme');fs.mkdirSync(OUT,{recursive:true});
const SR=16574.28,TAU=Math.PI*2;let seed=0x20261002;
const rand=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296*2-1};
const sine=(f,t)=>Math.sin(TAU*f*t);
// Band-limited pulse keeps the chip character without a piercing square edge.
function pulse(f,t,duty=.25){let v=0;for(let h=1;h<=7;h++)v+=Math.sin(Math.PI*h*duty)*Math.cos(TAU*f*h*t-Math.PI*h*duty)/h;return v*.77}
function tri(f,t){return 2/Math.PI*Math.asin(sine(f,t))}
const samples=[];
function add(name,seconds,fn,volume=48){const n=Math.min(65532,Math.floor(seconds*SR/2)*2),data=Buffer.alloc(n);let peak=0;const raw=new Float32Array(n);for(let i=0;i<n;i++){const v=fn(i/SR)*Math.min(1,i/48,(n-i)/100);raw[i]=v;peak=Math.max(peak,Math.abs(v))}const gain=peak>.96?.96/peak:1;for(let i=0;i<n;i++)data.writeInt8(Math.max(-127,Math.min(127,Math.round(raw[i]*gain*125))),i);samples.push({name,data,volume});return samples.length;}
const hat=t=>rand()*.30*Math.exp(-t*72);
const kick=t=>Math.tanh(Math.sin(TAU*(48*t+4.8*(1-Math.exp(-t*48))))*1.7)*.88*Math.exp(-t*12)+rand()*.16*Math.exp(-t*240);
const snare=t=>(rand()*.76+sine(194,t)*.30+sine(920,t)*.08)*Math.exp(-t*21);
const K=add('01 SOFT KICK+HAT',.34,t=>kick(t)+hat(t),56);
const S=add('02 CHIP SNARE+HAT',.25,t=>snare(t)+hat(t),44);
const H=add('03 TICK',.10,t=>hat(t),25);
const O=add('04 OPEN NOISE',.24,t=>rand()*.22*Math.exp(-t*19),29);
const KS=add('05 KICK+SNARE',.34,t=>(kick(t)+snare(t))*.8,54);
const B=add('06 TRIANGLE BASS',.65,t=>Math.tanh((tri(261.6256,t)*.67+pulse(261.6256,t,.49)*.38)*1.5)*Math.exp(-t*5),56);
const leadVoice=t=>Math.tanh((pulse(1046.5023,t,.23)*.7+pulse(1046.5023*1.004,t,.5)*.25)*1.5)*Math.exp(-t*3.8);
const L=add('07 WARM PULSE',.84,t=>leadVoice(t)+ (t>.24?leadVoice(t-.24)*.18:0),39);
const A=add('08 CRYSTAL ARP',.50,t=>(sine(1046.5023,t)*.53+sine(2093.0046,t)*.16+sine(3139.5,t)*.06)*Math.exp(-t*8),34);
function chord(major){return t=>{let v=0;for(const semi of [0,major?4:3,7,14]){const f=523.2511*2**(semi/12);v+=tri(f,t)*.11+sine(f,t)*.09}return v*Math.min(1,t*90)*Math.exp(-t*2.8)}}
const CM=add('09 MINOR ADD9',1.1,chord(false),33),CJ=add('0A MAJOR ADD9',1.1,chord(true),33);
const CR=add('0B SOFT SHIMMER',.9,t=>rand()*.24*Math.exp(-t*7),28);
const TOM=add('0C CHIP TOM',.24,t=>Math.sin(TAU*(105*t+1.5*(1-Math.exp(-t*24))))*Math.exp(-t*17)*.65,40);
const PAD=add('0D SINE MINOR PAD',1.9,t=>chord(false)(t)*Math.min(1,t*7)*1.5,36);
const FX=add('0E BOOT CHIRP',.52,t=>(sine(1046.5,t)*.4+sine(1569.75,t)*.16)*Math.exp(-t*8),29);
const BL=add('0F SOFT BELL',1.3,t=>(sine(1046.5,t)*.61+sine(2093,t)*Math.exp(-t*9)*.16+sine(3139.5,t)*.05)*Math.exp(-t*3.5),32);
const periods=[856,808,762,720,678,640,604,570,538,508,480,453,428,404,381,360,339,320,302,285,269,254,240,226,214,202,190,180,170,160,151,143,135,127,120,113];
const pat=[],names=theme.chapters.map(c=>c.name);
// Four-bar phrases: Am(add9), F(add9), C(add9), G(add9). Bridge: Dm F Am G.
const progressionA=[{root:9,major:false},{root:5,major:true},{root:0,major:true},{root:7,major:true}];
const progressionB=[{root:2,major:false},{root:5,major:true},{root:9,major:false},{root:7,major:true}];
// Each bar is deliberately voiced against its harmony; repeated themes develop.
const tuneA=[[4,7,9,12,11,9,7,4],[5,9,12,14,12,9,7,5],[4,7,12,16,14,12,7,4],[2,7,11,14,12,11,7,2]];
const tuneB=[[5,9,14,12,9,5,4,2],[5,9,12,16,14,12,9,7],[4,9,12,16,12,11,9,7],[7,11,14,17,14,12,11,7]];
function cell(sample=0,note=null,fx=0,param=0){if(note!==null)note=Math.max(0,Math.min(35,note));return{sample,note,period:note===null?0:periods[note],fx,param}}
function put(rows,row,ch,sample,note,volume){if(row>=0&&row<64)rows[row][ch]=cell(sample,note,0xC,volume)}
for(let p=0;p<24;p++){
 if(p===21)continue;
 const rows=Array.from({length:64},()=>Array.from({length:4},()=>cell()));
 const intro=p<2,quiet=p===14||p===15,outro=p>=22,peak=p>=16&&p<=21,bridge=p>=8&&p<14;
 const harmony=bridge?progressionB:progressionA,motifs=bridge?tuneB:tuneA,turbo=[6,10,18,20,21].includes(p);
 for(let bar=0;bar<4;bar++){
  const base=bar*16,{root,major}=harmony[bar],chordSample=major?CJ:CM;
  for(let step=0;step<16;step++){
   const r=base+step;let drum=0,vol=43;
   if(!quiet&&!outro&&(!intro||p===1||bar>=2)){
    if(step===0||step===8)drum=K,vol=56;
    if(step===4||step===12)drum=S,vol=43;
    if(step===2||step===6||step===10)drum=H,vol=step===6?20:26;
    if(step===14)drum=O,vol=25;
    if(peak&&step===11)drum=K,vol=40;
    if(p%4===3&&bar===3&&step>=12){drum=step%2?H:TOM;vol=step%2?18:38;}
   }
   if(outro&&p===22&&[0,4,8,12].includes(step)){drum=step%8?S:K;vol=34;}
   if(turbo){if(step%4===0){drum=K;vol=62}else if(step%4===2){drum=S;vol=55}else{drum=H;vol=30}}
   if(drum)put(rows,r,0,drum,24,vol); // Drums play at their synthesis rate.
  }
  if(!quiet&&!intro&&!outro){for(const [step,semi,vol]of [[0,0,54],[3,0,36],[6,7,43],[8,0,52],[11,12,36],[14,7,43]])put(rows,base+step,1,B,root+semi,vol)}
  else {put(rows,base,1,B,root,quiet?32:42);if(!quiet)put(rows,base+8,1,B,root+7,34)}
  // Harmony alternates warm sustained chords and glittering chip arpeggios.
  if(quiet||intro||outro||p%4===0){put(rows,base,2,chordSample,root+12,quiet?26:31);if(!quiet)put(rows,base+8,2,chordSample,root+12,23)}
  else {const chordNotes=[0,major?4:3,7,12,7,major?4:3,14,7];for(let n=0;n<(turbo?16:8);n++)put(rows,base+n*(turbo?1:2),2,A,root+chordNotes[n%8]+12,27+(n%2?0:6));}
  const motif=motifs[bar];
  if(intro||quiet||outro){const pick=p===23?[0,2,0,0]:[0,2,4,6];for(let n=0;n<4;n++)put(rows,base+n*4,3,BL,12+motif[pick[n]],quiet?27:30)}
  else if(peak){for(let n=0;n<8;n++)put(rows,base+n*2,3,L,12+motif[n],n%2?42:51)}
  else {const rhythm=[0,3,6,8,11,14],notes=[0,1,2,4,5,7];for(let n=0;n<rhythm.length;n++)put(rows,base+rhythm[n],3,p%4===2?BL:L,12+motif[notes[n]],n===0?49:42);}
  for(let r=base+1;r<base+16;r++)if(!rows[r][3].period&&rows[r-1][3].period&&!quiet)rows[r][3]=cell(0,null,0x4,turbo?0x35:0x13);
 }
 rows[0][0]=p===0?cell(FX,24,0xF,125):cell(0,null,0xF,125); // Timing only; reserve kick below.
 rows[0][1].fx=0xF;rows[0][1].param=6;
 if(p>0&&!quiet&&p<23)rows[0][0]=cell(p%4===0?CR:K,24,0xC,p%4===0?25:54);
 if(p===23){for(let r=0;r<64;r++)for(let ch=0;ch<4;ch++){if(rows[r][ch].sample){rows[r][ch].fx=0xC;rows[r][ch].param=Math.round(30*(1-r/80))}}}
 pat.push(rows);
}
const header=Buffer.alloc(1084);header.write('HUMAN / INPUT',0,'ascii');
for(let i=0;i<31;i++){const s=samples[i],o=20+i*30;if(!s){header.writeUInt16BE(1,o+28);continue}header.write(s.name.slice(0,22),o,'ascii');header.writeUInt16BE(s.data.length/2,o+22);header[o+25]=s.volume;header.writeUInt16BE(0,o+26);header.writeUInt16BE(1,o+28)}
header[950]=23;header[951]=127;for(let i=0;i<23;i++)header[952+i]=i;header.write('M.K.',1080,'ascii');
const pdata=Buffer.alloc(23*1024);for(let p=0;p<23;p++)for(let r=0;r<64;r++)for(let ch=0;ch<4;ch++){const v=pat[p][r][ch],o=p*1024+r*16+ch*4;pdata[o]=(v.sample&0xf0)|((v.period>>8)&15);pdata[o+1]=v.period&255;pdata[o+2]=((v.sample&15)<<4)|v.fx;pdata[o+3]=v.param;}
const mod=Buffer.concat([header,pdata,...samples.map(s=>s.data)]);fs.writeFileSync(path.join(OUT,'raster-ritual.mod'),mod);
fs.writeFileSync(path.join(DIR,'score.json'),JSON.stringify({title:theme.title,version:'human-input-2',bpm:125,speed:6,rowDuration:.12,patternDuration:7.68,duration:176.64,channels:4,sampleBits:8,samples:samples.map(s=>({name:s.name,bytes:s.data.length})),names,patterns:pat}));
require('./amiga-render.cjs');
