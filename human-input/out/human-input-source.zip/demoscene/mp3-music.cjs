// Clean stereo Suno soundtrack. No instrument conversion or Paula processing.
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),{spawnSync}=require('child_process');
const DIR=__dirname,OUT=path.join(DIR,'out'),ff=require('./tools.cjs').ffmpeg,source=path.join(OUT,'pixel-pulse-source.mp3'),SR=48000,BPM=95;
const sourcePhrase=720/BPM,phraseFrames=Math.round(sourcePhrase*SR),patternDuration=phraseFrames/SR,rowDuration=patternDuration/48,chapterDuration=patternDuration*2;
// One long reprise replaces the short, phrase-breaking tracker-era loops.
// The matching passages share beat phase and similar harmonic material.
const barDuration=240/BPM,repeatFrames=Math.round(52*barDuration*SR),joinFrame=Math.round(75*barDuration*SR),crossfadeFrames=Math.round(barDuration*SR);
const transition={at:joinFrame/SR,repeatFrom:(joinFrame-repeatFrames)/SR,repeatedDuration:repeatFrames/SR,crossfade:crossfadeFrames/SR};
const decoded=spawnSync(ff,['-v','error','-i',source,'-map','0:a:0','-ar',String(SR),'-ac','2','-f','f32le','pipe:1'],{windowsHide:true,maxBuffer:100000000});assert.equal(decoded.status,0,String(decoded.stderr));
const original=new Float32Array(decoded.stdout.buffer,decoded.stdout.byteOffset,decoded.stdout.length/4),full=new Float32Array(46*phraseFrames*2),duration=full.length/(SR*2);
const fadeStart=joinFrame-Math.floor(crossfadeFrames/2),fadeEnd=fadeStart+crossfadeFrames;
for(let i=0;i<full.length/2;i++){
 const u=Math.max(0,Math.min(1,(i-fadeStart)/crossfadeFrames)),blend=u*u*(3-2*u),gain=Math.min(1,(full.length/2-1-i)/(SR*4));
 for(let ch=0;ch<2;ch++){
  const first=i<fadeEnd?original[i*2+ch]||0:0,second=i>=fadeStart?original[(i-repeatFrames)*2+ch]||0:0;
  // Complementary gains keep the original peak headroom throughout the blend.
  full[i*2+ch]=(first*(1-blend)+second*blend)*gain;
 }
}
const raw=path.join(OUT,'clean-stereo.f32');fs.writeFileSync(raw,Buffer.from(full.buffer));
for(const [name,codec] of [['raster-ritual.wav',['-c:a','pcm_s16le']],['pixel-pulse.mp3',['-c:a','libmp3lame','-b:a','320k']]]){const r=spawnSync(ff,['-y','-v','error','-f','f32le','-ar',String(SR),'-ac','2','-i',raw,...codec,path.join(OUT,name)],{windowsHide:true,encoding:'utf8'});assert.equal(r.status,0,r.stderr)}fs.unlinkSync(raw);
const hop=480,env=[],bassEnv=[];let low=0;for(let base=0;base<full.length/2;base+=hop){let energy=0,bass=0;for(let i=base;i<Math.min(base+hop,full.length/2);i++){const v=(full[i*2]+full[i*2+1])*.5;low+=(v-low)*.018;energy+=v*v;bass+=low*low}env.push(Math.sqrt(energy/hop));bassEnv.push(Math.sqrt(bass/hop))}
const novelty=env.map((v,i)=>Math.max(0,v-(env[Math.max(0,i-3)]+env[Math.max(0,i-6)])*.5)+.65*Math.max(0,bassEnv[i]-bassEnv[Math.max(0,i-4)]));
const sorted=novelty.slice().sort((a,b)=>a-b),scale=sorted[Math.floor(sorted.length*.92)],peaks=[];
for(let i=4;i<novelty.length-4;i++)if(novelty[i]>scale*.4&&novelty[i]===Math.max(...novelty.slice(i-4,i+5))){const item=[i/100,+Math.min(1,novelty[i]/(scale*1.5)).toFixed(3)];if(!peaks.length||item[0]-peaks.at(-1)[0]>.09)peaks.push(item);else if(item[1]>peaks.at(-1)[1])peaks[peaks.length-1]=item}
const levels=[],energyScale=env.slice().sort((a,b)=>a-b)[Math.floor(env.length*.95)];for(let i=0;i<env.length;i+=5)levels.push([i/100,+Math.min(1,env.slice(i,i+5).reduce((a,b)=>a+b,0)/5/energyScale).toFixed(3)]);
const timing={bpm:BPM,beatDuration:60/BPM,beatOffset:-.03,rowDuration,patternDuration,rowsPerPattern:48,patternsPerChapter:2,chapterDuration,duration,transition,peaks,levels};
fs.writeFileSync(path.join(DIR,'timing.js'),`/* Clean MP3 edit: measured audio transients and stereo-source energy. */\n(function(root){const timing=${JSON.stringify(timing)};if(typeof module!=='undefined'&&module.exports)module.exports=timing;else root.DemoTiming=timing})(typeof window!=='undefined'?window:this);\n`);
const audit={source:'Pixel Pulse / original user-supplied Suno MP3',playback:'Native stereo MP3; no MOD, resampling emulation or synthesized instruments.',sourceDuration:original.length/(SR*2),duration,chapterDuration,bpm:BPM,sampleRate:SR,channels:2,mp3Bitrate:320000,arrangement:'Continuous opening and one long 52-bar reprise. No short loops or silent closing hold.',processing:'One bar of smooth complementary crossfade at matching beat phase; four-second final fade. Original stereo, pitch and tempo retained.',transition,transients:peaks.length};fs.writeFileSync(path.join(OUT,'music-audit.json'),JSON.stringify(audit,null,2));console.log(JSON.stringify(audit,null,2));
