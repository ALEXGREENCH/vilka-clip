/* RASTER / RITUAL — deterministic software demo. All geometry and pixels are code.
   Shared by the realtime player and the offline 50 Hz renderer. */
(function(root){
'use strict';
const TAU=Math.PI*2,PI=Math.PI,W=640,H=360,DURATION=176.64;
const S=Math.sin,C=Math.cos,clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),mix=(a,b,t)=>a+(b-a)*t,fract=v=>v-Math.floor(v),mod=(v,n)=>(v%n+n)%n;
const hash=n=>fract(S(n*127.13+19.19)*43758.5453);
const theme=typeof module!=='undefined'&&module.exports?require('./theme'):root.HumanInputTheme;
const impossible=typeof module!=='undefined'&&module.exports?require('./impossible'):root.ImpossibleFX;
const comedy=typeof module!=='undefined'&&module.exports?require('./comedy'):root.ComedyFX;
const geometry=typeof module!=='undefined'&&module.exports?require('./geometry'):root.SceneGeometry;
const names=theme.chapters.map(ch=>ch.name);
const families=[['starfield','copper','chrome logo'],['Amiga Boing Ball','checkerboard','sprite bounce'],['wireframe','hidden-face polygons','perspective'],['sine scroller','Lissajous ribbon'],['plasma','palette cycling'],['rotozoom','texture tiling'],['polar tunnel','radial distortion'],['analytic ray tracing','chrome spheres','reflections'],['metaballs','gradient bump shading'],['twister','Gouraud-like shading'],['AI logo parody','Boing Ball','comic timing'],['dot landscape','sine interference'],['voxel heightfield','fog'],['Julia fractal','orbit traps'],['vector orbit','wire sphere'],['particle morph','point cloud'],['torus knot','environment mapping'],['procedural city','camera flight'],['4D rotation','tesseract projection'],['Penrose triangle','cyclic occlusion'],['recursive portals','Droste zoom'],['greetings','sine scroll'],['chrome logo','copper fade']];
let canvas,c,pixel,pc,pdata,createCanvas,font='monospace',time=0,pulse=0;
const palettes=Array.from({length:8},(_,p)=>Array.from({length:256},(_,i)=>{const x=i/256*TAU;return [Math.round(128+127*S(x+p*.64)),Math.round(104+103*S(x+2+p*.18)),Math.round(145+110*S(x+4.2+p*.24))]}));
function rgb(r,g,b){return `rgb(${clamp(r,0,255)|0},${clamp(g,0,255)|0},${clamp(b,0,255)|0})`}
function hsl(h,l=60,s=85){return `hsl(${mod(h,360)},${s}%,${l}%)`}
function line(x,y,X,Y,col,width=1){c.strokeStyle=col;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(X,Y);c.stroke()}
function poly(v,col,stroke){c.beginPath();v.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.closePath();if(col){c.fillStyle=col;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=.7;c.stroke()}}
function text(str,x,y,size,col='#e9f4ff',align='left'){c.fillStyle=col;c.font=`${size}px ${font}`;c.textAlign=align;c.fillText(str,x,y);c.textAlign='left'}
function rot(v,a,b,d=0){let [x,y,z]=v;let q=x*C(a)+z*S(a);z=z*C(a)-x*S(a);x=q;q=y*C(b)-z*S(b);z=y*S(b)+z*C(b);y=q;return [x*C(d)-y*S(d),x*S(d)+y*C(d),z]}
function project(v,scale=185,zoff=4,cx=320,cy=174){const d=Math.max(.15,v[2]+zoff);return [cx+v[0]*scale/d,cy+v[1]*scale/d,d]}
function bg(top='#070719',bot='#211049'){const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,top);g.addColorStop(1,bot);c.fillStyle=g;c.fillRect(0,0,W,H)}
function stars(t,warp=0){for(let i=0;i<190;i++){let z=mod(hash(i+8)-t*(.025+warp*.04),1)+.05,xx=(hash(i*3)-.5)*500,yy=(hash(i*3+1)-.5)*280,x=320+xx/z,y=180+yy/z;if(x<0||x>640||y<0||y>360)continue;c.fillStyle=i%5?'#bfeaff':'#ffc9a1';c.globalAlpha=clamp(1-z)*.7+.1;const k=z<.2?2:1;c.fillRect(x,y,k,k);if(warp)line(x,y,x+xx/z*.1*warp,y+yy/z*.1*warp,'#6c86c6',1)}c.globalAlpha=1}
function copper(t,amp=1){for(let j=0;j<7;j++){let y=180+S(t*.9+j*.53)*112;for(let k=-12;k<=12;k++){let light=14+Math.pow(1-Math.abs(k)/13,.6)*60;c.fillStyle=hsl(j*35+t*15,light);c.globalAlpha=amp;c.fillRect(0,y+k,W,1)}}c.globalAlpha=1}
function floor(t,horizon=223){const f=320+S(t*.3)*55;for(let j=0;j<16;j++){const z1=mod(j/16+t*.18,1),z2=z1+.065,y1=horizon+z1*z1*175,y2=horizon+z2*z2*175,s1=6+z1*100,s2=6+z2*100;for(let i=-9;i<9;i++)poly([[f+i*s1,y1],[f+(i+1)*s1,y1],[f+(i+1)*s2,y2],[f+i*s2,y2]],(i+j)%2?'#322662':'#11152e');line(0,y1,640,y1,'#573974')}line(0,horizon,640,horizon,'#9774ca')}
function logo(t,small=false){c.save();const y=small?155:160;const g=c.createLinearGradient(0,y-76,0,y+13);g.addColorStop(0,'#d8ecff');g.addColorStop(.33,'#656d9d');g.addColorStop(.47,'#fafbff');g.addColorStop(.5,'#fff');g.addColorStop(.53,'#201241');g.addColorStop(.75,'#a273c9');g.addColorStop(1,'#eab6fa');c.textAlign='center';c.font='italic 900 96px Impact, Arial Black, sans-serif';c.lineJoin='round';c.lineWidth=5;c.strokeStyle='#27193f';c.strokeText('HUMAN',318,y);c.fillStyle=g;c.shadowColor='#dc72ff';c.shadowBlur=14;c.fillText('HUMAN',318,y);c.shadowBlur=0;text('/ /  I N P U T',320,y+32,19,'#edcae9','center');text('AI IS A TOOL. YOU ARE THE REASON.',320,y+59,8,'#b4c8e4','center');c.restore();}
function pixels(fn){const d=pdata.data;for(let y=0;y<180;y++)for(let x=0;x<320;x++){const i=(y*320+x)*4;const col=fn((x-160)/90,(y-90)/90,x,y);d[i]=col[0];d[i+1]=col[1];d[i+2]=col[2];d[i+3]=255}pc.putImageData(pdata,0,0);c.imageSmoothingEnabled=false;c.drawImage(pixel,0,0,640,360)}
function plasma(t){const pal=palettes[1];pixels((x,y)=>{const v=S(x*3+t)+S(y*4-t*.7)+S((x+y)*2+t*.8)+S(Math.hypot(x+.6*S(t),y+.4*C(t))*6-t*1.8);return pal[mod((v*31+t*25)|0,256)]})}
function rotozoom(t){const a=t*.42,co=C(a),si=S(a),zoom=.9+.6*S(t*.33);pixels((x,y)=>{let u=(x*co-y*si)*zoom+t*.12,v=(x*si+y*co)*zoom;const check=((Math.floor(u*12)^Math.floor(v*12))&1);const rings=Math.sin(Math.hypot(fract(u*3)-.5,fract(v*3)-.5)*24);let k=mod((u*55+v*65+t*18)|0,256);let col=palettes[3][k];return col.map(z=>(z*(check?.72:.2)+Math.max(0,rings)*55))})}
function tunnel(t,variant=0){pixels((x,y)=>{
 x+=.20*S(t*.7);y+=.15*C(t*.61);const r=Math.max(.045,Math.hypot(x,y)),a=Math.atan2(y,x)+.18*S(3/r-t);
 // Integer angular harmonics join exactly across the circular texture seam.
 const u=a/TAU*16+t*.5,v=2/r-t*2.4+pulse*.11;
 const checker=.5+.5*Math.tanh(C(PI*u)*C(PI*v)*5),wire=Math.pow(Math.abs(S(PI*u)),20)+Math.pow(Math.abs(S(PI*v)),22);
 const shade=clamp(r*1.1),phase=a*2+v*.19+t*.35+(variant?1.7:0);
 return [0,2,4].map((shift,i)=>Math.min(255,((115+100*S(phase+shift))*(.25+.40*checker)+wire*(i===2?125:85))*shade));
})}
function raytrace(t){const centers=[[-.95+S(t*.52)*.15,.10,3.7],[.9,-.1+C(t*.61)*.28,4.2],[S(t*.4)*.4,-.85,4.9]],radius=[.83,.94,.72].map(r=>r*(1+pulse*.025));
 const env=(x,y,z)=>{const h=.5+.5*y,band=Math.pow(Math.max(0,S(y*15+z*3)),14);return [30+150*h+band*45,20+100*h+band*70,55+155*h+band*45]};
 pixels((u,v)=>{let dx=u*.7,dy=v*.7,dz=1,len=Math.hypot(dx,dy,dz);dx/=len;dy/=len;dz/=len;let near=1e6,hit=-1;for(let j=0;j<3;j++){let q=centers[j],b=dx*q[0]+dy*q[1]+dz*q[2],disc=b*b-(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]-radius[j]*radius[j]);if(disc>0){let d=b-Math.sqrt(disc);if(d>0&&d<near){near=d;hit=j}}}
  const floorD=dy>.001?1.15/dy:1e6;
  if(hit>=0&&near<floorD){const q=centers[hit],nx=(dx*near-q[0])/radius[hit],ny=(dy*near-q[1])/radius[hit],nz=(dz*near-q[2])/radius[hit],dot=dx*nx+dy*ny+dz*nz,rx=dx-2*dot*nx,ry=dy-2*dot*ny,rz=dz-2*dot*nz;let col=env(rx,-ry,rz);const ox=dx*near+nx*.002,oy=dy*near+ny*.002,oz=dz*near+nz*.002;let rd=1e6,rhit=-1;for(let j=0;j<3;j++){if(j===hit)continue;const bq=centers[j],xx=bq[0]-ox,yy=bq[1]-oy,zz=bq[2]-oz,bb=rx*xx+ry*yy+rz*zz,disc=bb*bb-(xx*xx+yy*yy+zz*zz-radius[j]*radius[j]);if(disc>0){const dd=bb-Math.sqrt(disc);if(dd>0&&dd<rd){rd=dd;rhit=j}}}const fd=ry>.001?(1.15-oy)/ry:1e6;if(rhit>=0&&rd<fd){col=[106,135,191]}else if(fd>0&&fd<60){const xx=ox+rx*fd,zz=oz+rz*fd+t*.35,checker=(Math.floor(xx*1.5)^Math.floor(zz*1.5))&1;col=checker?[190,139,221]:[29,24,61]}let spec=Math.pow(Math.max(0,-nx*.3-ny*.7-nz*.6),36)*200;const fres=.3+.7*Math.pow(1+dot,3);return col.map(z=>clamp(z*(.75+fres*.25)+spec,0,255));}
  if(floorD<40){let xx=dx*floorD,zz=dz*floorD+t*.35,check=(Math.floor(xx*1.5)^Math.floor(zz*1.5))&1,fog=Math.exp(-floorD*.055),shade=1;for(const q of centers){const dist=(xx-q[0])**2+(dz*floorD-q[2])**2;shade*=1-.6*Math.exp(-dist*1.7)}return [(check?126:31)*fog*shade+12,(check?66:21)*fog*shade+9,(check?175:49)*fog*shade+30]}
  return env(dx,-dy,dz).map(z=>z*.19);
 });}
function metaballs(t){const balls=Array.from({length:6},(_,i)=>[S(t*.7+i*2.4)*1.04,C(t*.52+i*1.9)*.63,.19+.06*S(t+i)]);pixels((x,y)=>{let v=0,gx=0,gy=0;for(const b of balls){let xx=x-b[0],yy=y-b[1],d=xx*xx+yy*yy+.045;v+=b[2]/d;gx-=b[2]*xx/(d*d);gy-=b[2]*yy/(d*d)}if(v<1.35)return [8+v*7,8+v*6,22+v*15];const norm=Math.hypot(gx,gy,2),light=clamp((-gx*.4-gy*.6+1.3)/norm),spec=Math.pow(light,12)*220,ring=.5+.5*S(v*1.2+t*.3);return [40+light*70+spec+ring*40,32+light*170+spec,80+light*150+spec]})}
function julia(t){const ang=t*.11,co=C(ang),si=S(ang),zoom=1.4+.5*S(t*.17),cr=-.7+.008*S(t*.13),ci=.27015+.005*C(t*.16);pixels((x,y)=>{let zx=(x*co-y*si)*zoom,zy=(x*si+y*co)*zoom,n=0,trap=10;for(;n<42;n++){let xx=zx*zx-zy*zy+cr;zy=2*zx*zy+ci;zx=xx;trap=Math.min(trap,Math.abs(zx*.4+zy));if(zx*zx+zy*zy>64)break}if(n===42)return [6+trap*25,7,21+trap*50];let color=palettes[5][mod((n*8+t*15-Math.log(Math.max(.01,trap))*9)|0,256)];return color.map(z=>z*(.55+n/90))})}
const verts=[[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],edges=[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]],faces=[[0,1,2,3],[4,7,6,5],[0,4,5,1],[1,5,6,2],[2,6,7,3],[3,7,4,0]];
function cube(t,size=1,cx=320,cy=170,zoff=4,solid=false,hue=180){size*=1+pulse*.045;const vv=verts.map(v=>rot(v.map(x=>x*size),t*.6,t*.37,t*.17)),pp=vv.map(v=>project(v,205,zoff,cx,cy));if(solid){faces.map(f=>({f,z:f.reduce((s,i)=>s+vv[i][2],0)})).sort((a,b)=>b.z-a.z).forEach(({f,z})=>poly(f.map(i=>pp[i]),hsl(hue+z*13,28+(z+size*4)*5),hsl(hue+20,72)))}else edges.forEach(([a,b])=>line(...pp[a].slice(0,2),...pp[b].slice(0,2),hsl(hue,55+(pp[a][2]%2)*12),1));}
function vectorTemple(t){
 bg('#050a17','#132338');stars(t*.5);
 // One rigid cube with a generous camera distance and properly culled solid faces.
 const ground=1.9,depth=6.6,f=270,cy=168;
 for(let z=18;z>1;z--)for(let x=-8;x<8;x++)poly([[x,ground,z],[x+1,ground,z],[x+1,ground,z+1],[x,ground,z+1]].map(v=>geometry.project(v,f,320,cy)),(x+z)%2?'#172b3a':'#10202e');
 const shadow=geometry.project([0,ground,depth],f,320,cy);c.fillStyle='rgba(0,0,8,.36)';c.beginPath();c.ellipse(shadow[0],shadow[1],71,13,0,0,TAU);c.fill();
 const vv=verts.map(v=>{const q=rot(v.map(x=>x*1.34),t*.48,t*.29,.12*S(t*.31));return[q[0],q[1]-.58,q[2]+depth]});
 geometry.faces.map((face,i)=>({v:face.map(k=>vv[k]),i})).filter(p=>geometry.visible(p.v)).sort((a,b)=>b.v.reduce((n,v)=>n+v[2],0)-a.v.reduce((n,v)=>n+v[2],0)).forEach(({v,i})=>{
  const n=geometry.normal(v),len=Math.hypot(...n),light=.28+.72*Math.max(0,(-n[0]*.35-n[1]*.55-n[2]*.75)/len),pp=v.map(q=>geometry.project(q,f,320,cy));
  const g=c.createLinearGradient(230,70,420,270);g.addColorStop(0,hsl(183+i*14,22+light*35));g.addColorStop(1,hsl(224+i*8,14+light*26));poly(pp,g,'#99edfa');
 });
}
function scroller(t,message,y=260,size=23,speed=113,travel=26){
 const gap=size*1.22,total=message.length*gap,start=640-mod(t*speed+200,total+700),lift=S(t*1.6)*travel+S(t*.67)*travel*.24;
 for(let i=0;i<message.length;i++){const x=start+i*gap;if(x<-35||x>670)continue;
  const wave=x*.017+t*2.5,yy=y+lift+S(wave)*Math.min(16,travel*.6),hue=t*42+x*.13;
  c.save();c.translate(x,yy);c.rotate(C(wave)*.10);
  const g=c.createLinearGradient(0,-size,0,4);g.addColorStop(0,'#fff6db');g.addColorStop(.28,hsl(hue,75));g.addColorStop(.53,hsl(hue+65,48));g.addColorStop(.56,'#edfbff');g.addColorStop(1,hsl(hue+150,60));
  text(message[i],2,3,size,'#070916');text(message[i],0,0,size,g);c.restore();
 }
}
function ribbons(t){bg();for(let j=0;j<5;j++){c.beginPath();for(let i=0;i<500;i++){let a=i/500*TAU,x=320+220*S(a*2+t*.4+j*.03),y=155+85*S(a*3+t*.2+j*.07);i?c.lineTo(x,y):c.moveTo(x,y)}c.strokeStyle=hsl(j*38+t*25,60);c.lineWidth=3;c.stroke()}scroller(t,'YOU HUM IT. I DO THE MATH.  ///  A NEW INSTRUMENT. STILL YOUR MUSIC.  ///  AI IS A TOOL.  ///  ',263,23,113,26)}
function twister(t){bg('#080a24','#33214b');stars(t);for(let y=25;y<326;y+=2){let a=y*.018+S(t*.7)*2+t*1.1,cx=320+S(y*.013+t)*65;for(let j=0;j<4;j++){let x1=cx+S(a+j*PI/2)*(93+pulse*6),x2=cx+S(a+(j+1)*PI/2)*(93+pulse*6);if(x1<x2){let lum=30+45*Math.max(0,C(a+j*PI/2+PI/4));c.fillStyle=hsl(j*63+t*12,lum);c.fillRect(x1,y,x2-x1+1,2)}}}}
function vectorballs(t){bg();floor(t,275);const pts=[];for(let i=0;i<140;i++){let a=i/140*TAU*7,b=i/140*PI,r=1.85+.3*S(t+i*.2)+pulse*.05,v=rot([r*S(b)*C(a),r*C(b),r*S(b)*S(a)],t*.35,t*.6),p=project(v,210,3.8);pts.push({p,i,z:v[2]})}pts.sort((a,b)=>b.z-a.z).forEach(({p,i})=>{const r=15/p[2],g=c.createRadialGradient(p[0]-r*.3,p[1]-r*.4,.2,p[0],p[1],r);g.addColorStop(0,'#f4ffff');g.addColorStop(.35,hsl(i*2+t*12,60));g.addColorStop(1,'#1c1244');c.fillStyle=g;c.beginPath();c.arc(p[0],p[1],r,0,TAU);c.fill()})}
function dots(t){bg('#071422','#102735');for(let z=42;z>=1;z--)for(let x=-28;x<=28;x++){let zz=z+fract(t*3),height=S(x*.22+t)*.55+C(zz*.3-t*.8)*.7,p=project([x*.27,height+1,zz*.25],270,1,320,120);const k=clamp(4-z*.07,1,4);c.fillStyle=hsl(166+height*65,65-z*.65);c.fillRect(p[0],p[1],k,k)}stars(t*.4)}
function height(x,z){return 30+S(x*.042+S(z*.011)*2)*19+C(z*.034)*17+S((x+z)*.07)*8+S(x*.015-z*.019)*24}
function voxel(t){bg('#08152c','#a24766');const sun=c.createRadialGradient(434,98,2,434,98,53);sun.addColorStop(0,'#fff1ae');sun.addColorStop(.6,'#f79283');sun.addColorStop(1,'#6e395d');c.fillStyle=sun;c.beginPath();c.arc(434,98,53,0,TAU);c.fill();const yaw=S(t*.19)*.45,co=C(yaw),si=S(yaw),camx=t*7,camz=t*27,camh=96+S(t*.5)*12,clip=new Float32Array(320).fill(360);for(let z=3;z<360;z+=1.2+z*.007){for(let x=0;x<320;x++){const off=(x-160)/140*z,xx=camx+co*off+si*z,zz=camz+co*z-si*off,hh=height(xx,zz),yy=155+(camh-hh)/z*140;if(yy<clip[x]){const light=(height(xx+3,zz)-hh)*.14+.65,fog=clamp(z/360);c.fillStyle=rgb(mix(28+hh*.6,110,fog)*light,mix(53+hh*1.2,74,fog)*light,mix(53+hh*.9,106,fog)*light);c.fillRect(x*2,Math.max(0,yy),2,clip[x]-Math.max(0,yy)+1);clip[x]=Math.max(0,yy)}}}}
function orbit(t){bg('#060914','#0c1521');stars(t*.4);for(let j=0;j<18;j++){const lat=(j/17-.5)*PI;const pts=[];for(let i=0;i<=64;i++){const a=i/64*TAU,v=rot([1.35*C(lat)*C(a),1.35*S(lat),1.35*C(lat)*S(a)],t*.12,.5,t*.04);pts.push(project(v,190,3.8))}c.strokeStyle=hsl(183+j*3,25+j*2);c.lineWidth=.65;c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.stroke()}text('WAITING FOR HUMAN INPUT_',320,291,10,'#94b1ba','center')}
function morph(t){bg('#080714','#281337');const points=[],blend=.5-.5*C(t*.8);for(let i=0;i<1400;i++){let u=hash(i)*TAU,v=Math.acos(hash(i+1900)*2-1),a=[S(v)*C(u)*1.6,C(v)*1.6,S(v)*S(u)*1.6],b=[(hash(i+20)-.5)*2.7,(hash(i+40)-.5)*2.7,(hash(i+60)-.5)*2.7];if(i%3===0)b[0]=Math.sign(b[0])*1.35;if(i%3===1)b[1]=Math.sign(b[1])*1.35;if(i%3===2)b[2]=Math.sign(b[2])*1.35;let q=rot(a.map((n,j)=>mix(n,b[j],blend)),t*.35,t*.21),p=project(q,300+pulse*8,4);points.push({p,i,z:q[2]})}points.sort((a,b)=>b.z-a.z);for(const {p,i,z}of points){let k=z<0?2:1;c.fillStyle=hsl(195+z*50+i%14,60-z*12);c.fillRect(p[0],p[1],k,k)}}
function knot(t){bg('#100918','#171d36');stars(t);const rows=92,cols=12,mesh=[];for(let i=0;i<rows;i++){let a=i/rows*TAU,rr=1+.35*C(3*a),center=[rr*C(2*a),rr*S(2*a),.5*S(3*a)];let ap=a+.001,rp=1+.35*C(3*ap),next=[rp*C(2*ap),rp*S(2*ap),.5*S(3*ap)],tan=next.map((v,j)=>v-center[j]),len=Math.hypot(...tan);tan=tan.map(v=>v/len);let n=[-tan[1],tan[0],0],nl=Math.hypot(...n);n=n.map(v=>v/nl);let b=[tan[1]*n[2]-tan[2]*n[1],tan[2]*n[0]-tan[0]*n[2],tan[0]*n[1]-tan[1]*n[0]];mesh[i]=[];for(let j=0;j<cols;j++){let q=j/cols*TAU,normal=n.map((v,k)=>v*C(q)+b[k]*S(q)),v=center.map((v,k)=>v+normal[k]*.26);mesh[i][j]={v:rot(v,t*.34,t*.28),n:rot(normal,t*.34,t*.28)}}}const quads=[];for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){const q=[mesh[i][j],mesh[(i+1)%rows][j],mesh[(i+1)%rows][(j+1)%cols],mesh[i][(j+1)%cols]];quads.push({q,z:q.reduce((a,b)=>a+b.v[2],0)/4})}quads.sort((a,b)=>b.z-a.z).forEach(({q})=>{const n=q[0].n,band=Math.pow(.5+.5*S(n[1]*9+n[0]*4+t*.2),5),spec=Math.pow(clamp(-n[0]*.3-n[1]*.6-n[2]*.7),18);const col=rgb(48+band*145+spec*130,50+band*125+spec*150,94+band*135+spec*170);poly(q.map(p=>project(p.v,310+pulse*8,3.8)),col,col)})}
function city(t){
 bg('#060c22','#30223f');stars(t*.3);
 const ground=1.6,stride=3.2,camZ=t*3.7,camX=S(t*.25)*.16,yaw=S(t*.19)*.026,first=Math.floor(camZ/stride)-2,polygons=[];
 const camera=v=>geometry.camera(v,camX,camZ,yaw);
 const draw=(v,fill,stroke)=>{const clipped=geometry.clipNear(v);if(clipped.length>=3)poly(clipped.map(q=>geometry.project(q,265,320,143)),fill,stroke)};
 // Road, pavements and building foundations share y=ground and one camera.
 for(let row=first+24;row>=first;row--)for(let lane=-5;lane<5;lane++){
  const x=lane*1.6,z=row*stride,depth=z+stride*.5-camZ,fog=clamp(1-depth/75);
  draw([[x,ground,z],[x+1.6,ground,z],[x+1.6,ground,z+stride],[x,ground,z+stride]].map(camera),lane===-1||lane===0?'#121524':((row+lane)&1)?rgb(23*fog,34*fog,55*fog):rgb(17*fog,24*fog,41*fog),`rgba(88,133,176,${fog*.28})`);
 }
 for(let row=first;row<=first+24;row++)for(const side of [-1,1])for(let lane=0;lane<3;lane++){
  const seed=row*7+lane*31+(side+1)*139,z=row*stride+stride*.5,x=side*(2.55+lane*1.9),h=.95+hash(seed)*3.7;
  const vv=verts.map(v=>camera([x+v[0]*.62,ground+(v[1]-1)*h*.5,z+v[2]*.86]));
  for(let i=0;i<geometry.faces.length;i++){const v=geometry.faces[i].map(k=>vv[k]);if(geometry.visible(v))polygons.push({v,i,seed,depth:v.reduce((sum,p)=>sum+p[2],0)/4})}
 }
 polygons.sort((a,b)=>b.depth-a.depth).forEach(({v,i,seed,depth})=>{
  const fog=clamp(1-depth/76),shade=[.72,.66,1.15,.85,.42,.55][i],tone=hash(seed)*28;
  draw(v,rgb((40+tone)*fog*shade,(63+tone)*fog*shade,(110+tone)*fog*shade),`rgba(135,188,227,${fog*.72})`);
 });
}
function recursive(t){bg('#080612','#271a46');for(let i=13;i>=0;i--){let s=mod(i/14+t*.12,1),size=.1+s*s*3.1;c.globalAlpha=.25+s*.7;cube(t*.55+i*.17,size,320,180,4.2,false,260+i*13)}c.globalAlpha=1}
function hyperspace(t){bg('#070a16','#0d1b39');stars(t,2);for(let i=30;i>=0;i--){const z=mod(i*.35-t*1.9,10.8)+.4,r=140/z,cx=320+S(z*.4+t*.6)*60,cy=180+C(z*.5+t*.5)*38;c.strokeStyle=hsl(175+z*18,70-z*3);c.lineWidth=clamp(3/z,.6,4);c.beginPath();for(let j=0;j<=12;j++){let a=j/12*TAU+t*.2+z*.08,x=cx+C(a)*r*1.5,y=cy+S(a)*r;j?c.lineTo(x,y):c.moveTo(x,y)}c.stroke()}}
function ascent(t){bg('#0d0a1e','#40243d');const quads=[];for(let j=0;j<24;j++)for(let i=0;i<8;i++){const a=i/8*TAU,r=2.2+.25*S(j*.7),y=mod(j*.75+t*2,18)-9,x=C(a)*r,z=S(a)*r;let vv=verts.map(v=>rot([x+v[0]*.20,y+v[1]*.21,z+v[2]*.20],t*.18,.3));for(const f of faces)quads.push({vs:f.map(k=>vv[k]),z:f.reduce((s,k)=>s+vv[k][2],0),a,j})}quads.sort((a,b)=>b.z-a.z).forEach(({vs,a,j,z})=>poly(vs.map(v=>project(v,160,4)),hsl(28+j*2,25+clamp(4-z,0,10)*4),hsl(28+j*2,65)));c.globalAlpha=.3;for(let i=0;i<14;i++)line(320,170,hash(i)*640,360,'#ffd9ab');c.globalAlpha=1}
function greets(t){bg();stars(t);const groups=['FUTURE CREW / KEFRENS / SPACEBALLS','SANITY / TRITON / THE BLACK LOTUS','FARBRAUSCH / CONSPIRACY / ASD','FAIRLIGHT / CNCD / KEWLERS / MFX','ANDROMEDA / TITAN / BOOZE DESIGN'];text('RESPECT TO THE SCENE',320,65+S(t*1.3)*5,17,'#f8d0aa','center');
 for(let i=0;i<groups.length;i++){const y=107+i*26+S(t*1.6+i*.42)*9,g=c.createLinearGradient(0,y-10,0,y+2);g.addColorStop(0,'#e9fcff');g.addColorStop(.48,hsl(170+i*28+t*35,68));g.addColorStop(1,hsl(235+i*28+t*35,50));text(groups[i],320+S(t*.8+i*.3)*9,y,9,g,'center')}
 text('MACHINE GENERATED. HUMAN INITIATED.',320,268,8,'#b2bed2','center');scroller(t,'GREETINGS TO EVERYONE WHO MADE A COMPUTER SING.   KEEP THE SCENE ALIVE.   ',308,15,107,12)}
function drawScene(idx,t,local){switch(idx){case 0:bg();stars(t,1);copper(t,.22);floor(t,251);logo(t);break;case 1:comedy.draw(c,t,local,false);break;case 2:vectorTemple(t);break;case 3:ribbons(local);break;case 4:plasma(t);cube(t,1.7,320,180,4.3,false,180);break;case 5:rotozoom(t);break;case 6:if(local>3.84){const cut=Math.floor(local/.24)%3;if(cut===0)tunnel(t*1.9);else if(cut===1)plasma(t*2);else rotozoom(t*2)}else tunnel(t*1.4);break;case 7:raytrace(t);break;case 8:metaballs(t);break;case 9:twister(t);break;case 10:comedy.draw(c,t,local,true);break;case 11:dots(t);break;case 12:voxel(t);break;case 13:julia(t);break;case 14:orbit(t);break;case 15:morph(t);break;case 16:knot(t);break;case 17:city(t);break;case 18:impossible.draw(c,0,t,local,pulse);break;case 19:impossible.draw(c,1,t,local,pulse);break;case 20:{const cut=Math.floor(local/.24)%4;if(cut<2)impossible.draw(c,2,t,local*1.8,pulse);else if(cut===2)impossible.draw(c,0,t,local*1.7,pulse);else comedy.draw(c,t,local,true);break;}case 22:greets(local);break;case 23:bg();stars(t);copper(t,.12);logo(t,true);text('YOUR TURN.',320,268,17,'#fbd6ac','center');text('MACHINE GENERATED. HUMAN INITIATED.',320,297,8,'#b7abcb','center');break;}}
function render(t,options={}){time=clamp(t,0,DURATION);const beat=t/.48; pulse=Math.exp(-fract(beat)*8);const idx=Math.min(22,Math.floor(t/7.68)),local=t-idx*7.68;c.save();c.globalAlpha=1;c.globalCompositeOperation='source-over';drawScene(idx>=21?idx+1:idx,t,local);
 if(idx>0&&idx<21){const phrase=theme.chapters[idx].line,opacity=clamp((local-.55)/.4)*clamp((7.05-local)/.7);c.save();c.globalAlpha=opacity;const g=c.createLinearGradient(0,290,0,344);g.addColorStop(0,'rgba(4,5,14,0)');g.addColorStop(1,'rgba(4,5,14,.92)');c.fillStyle=g;c.fillRect(0,287,640,57);text(phrase,320,327,9,'#f5d6b7','center');text(theme.chapters[idx].act,16,34,6,'#beb2d0');c.restore();}

 if((idx===6&&local>3.84)||idx===20){text('TURBO / 250',623,42,8,'#ffdc8d','right');}
 // Musical transition: eased dark transition over three rows, never white strobing.
 const edge=clamp(Math.min(local,(7.68-local))/.38),gate=edge*edge*(3-2*edge);if(gate<1&&idx!==0){c.fillStyle=`rgba(4,5,14,${1-clamp(gate)})`;c.fillRect(0,0,640,360)}
 c.fillStyle='rgba(4,5,12,.78)';c.fillRect(0,0,640,16);c.fillRect(0,344,640,16);text('HUMAN / INPUT',12,11,7,'#aaa9bc');text(`${String(idx+1).padStart(2,'0')} / ${names[idx]}`,628,11,7,'#cabdda','right');text('M.K.  /  4CH  /  125 BPM',12,355,6,'#928cac');for(let i=0;i<23;i++){c.fillStyle=i===idx?'#ffb578':i<idx?'#66506e':'#272334';c.fillRect(429+i*8,351,5,3)}
 // Thin raster mask, with a restrained edge vignette.
 if(options.scanlines!==false){c.fillStyle='rgba(0,0,0,.11)';for(let y=17;y<344;y+=2)c.fillRect(0,y,640,1)}
 if(idx===0&&t<.7||t>172.8){let alpha=idx===0?1-t/.7:(t-172.8)/3.84;c.fillStyle=`rgba(0,0,0,${clamp(alpha)})`;c.fillRect(0,0,640,360)}c.restore();return canvas;}
const api={init(opts){createCanvas=opts.createCanvas;impossible.init(createCanvas);comedy.init(createCanvas);font=opts.font||'monospace';canvas=createCanvas(640,360);c=canvas.getContext('2d');pixel=createCanvas(320,180);pc=pixel.getContext('2d');pdata=pc.createImageData(320,180);return api},render,names,families,duration:DURATION,width:W,height:H};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.RasterRitual=api;
})(typeof window!=='undefined'?window:this);
