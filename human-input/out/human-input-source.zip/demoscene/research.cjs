const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'research');
const clean=s=>s.replace(/<[^>]+>/g,' ').replace(/&amp;/g,'&').replace(/&#039;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();
async function get(url){const r=await fetch(url,{signal:AbortSignal.timeout(25000)});if(!r.ok)throw Error(r.status+' '+url);return r.text()}
(async()=>{
let items=[];
for(let page=1;page<=4;page++){let url=`https://www.pouet.net/prodlist.php?type%5B%5D=demo&order=views&page=${page}`;let html=await get(url);fs.writeFileSync(path.join(root,`ranking-${page}.html`),html);for(const m of html.matchAll(/<span class='prod'><a href='prod.php\?which=(\d+)'>(.*?)<\/a>/g))items.push({rank:items.length+1,id:m[1],name:clean(m[2]),url:'https://www.pouet.net/prod.php?which='+m[1]});}
if(items.length!==100||new Set(items.map(p=>p.id)).size!==100)throw Error('Expected 100 unique entries: '+items.length);
const terms=['plasma','copper','raster','scroller','scrolltext','rotozoom','tunnel','twister','vector','wireframe','gouraud','metaball','blob','particle','voxel','landscape','terrain','raymarch','raytrac','fractal','mandelb','julia','feedback','bump','environment map','texture','morph','sync','tracker','soundtrack','design','typography','sine','water','city','cube','sphere','torus'];
let index=0;
async function worker(){while(index<items.length){const p=items[index++];try{const api=JSON.parse(await get('https://api.pouet.net/v1/prod/?id='+p.id)).prod;const html=await get(p.url);fs.writeFileSync(path.join(root,'prod-'+p.id+'.html'),html);p.group=api.groups.map(g=>g.name).join(' + ');p.platform=Object.values(api.platforms).map(x=>x.name).join(', ');p.date=api.releaseDate;p.popularity=api.popularity;p.votes={up:api.voteup,down:api.votedown};p.links=api.downloadLinks;p.demozoo=api.demozoo;p.mentions=terms.filter(term=>clean(html).toLowerCase().includes(term));p.status='catalogue and production page inspected';}catch(e){p.error=e.message;}if(p.rank%10===0)console.log('RESEARCH',p.rank,p.name);}}
await Promise.all([worker(),worker(),worker(),worker()]);
fs.writeFileSync(path.join(root,'top100.json'),JSON.stringify({retrieved:'2026-10-02',method:'First 100 demo-category entries sorted by Pouet popularity (order=views). Metadata and text of production pages; not a claim of watching 100 complete videos. Effect words are page mentions, including comments, not verified attribution.',ranking:'https://www.pouet.net/prodlist.php?type%5B%5D=demo&order=views',items},null,2));
console.log('COMPLETE',items.length,'errors',items.filter(p=>p.error).length);console.log(items.map(p=>`${p.rank}. ${p.name} / ${p.group} / ${p.mentions?.join(', ')}`).join('\n'));
})();
