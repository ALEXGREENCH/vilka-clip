'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const {createCanvas}=require('@napi-rs/canvas');
const {makeCore,step,screen,toCanvas,symbols}=require('./verify.cjs');
async function run(){
 const c=await makeCore(0,true),sheet=createCanvas(1024,240),ctx=sheet.getContext('2d');
 ctx.fillStyle='#101216';ctx.fillRect(0,0,1024,240);let samples=[],finishedAt=null;
 for(let f=1;f<=400;f++){
  step(c,1);
  if([30,85,120,240].includes(f)){
   const scr=screen(c),image=toCanvas(scr),n=samples.length;
   ctx.drawImage(image,n*256,0);ctx.fillStyle='#bbc0ce';ctx.font='13px Consolas';ctx.fillText(`${(f/50).toFixed(1)} s`,n*256+10,217);
   fs.writeFileSync(path.join(__dirname,`out/intro-${f}.png`),image.toBuffer('image/png'));
   samples.push({frame:f,active:c.peek(symbols.intro_active),shatterFrame:c.peek(symbols.intro_frame),visibleCells:[...scr.subarray(6144)].filter(a=>a!==0).length});
   if(f===30){assert.equal(c.peek(symbols.intro_active),1);assert.equal(c.peek(symbols.sound),0);assert(samples[0].visibleCells>740);}
  }
  if(f>30&&!c.peek(symbols.intro_active)&&finishedAt===null)finishedAt=f;
 }
 assert(finishedAt>100&&finishedAt<300,'Bounded native intro duration');
 assert.equal(c.peek(symbols.scene),0,'First scene follows the intro');
 assert.equal(c.peek(symbols.sound),1,'AY starts after the loader collapse');
 assert(c.peek(symbols.render_count)>0);assert.equal(c.getIM(),2);assert.equal(c.peek(0xfe80),0xfd);
 const skipped=await makeCore(0);step(skipped,30);assert.equal(skipped.peek(symbols.intro_active),0,'Chapter snapshot skips the intro');assert(skipped.peek(symbols.render_count)>0);
 fs.writeFileSync(path.join(__dirname,'out/intro-contact-sheet.png'),sheet.toBuffer('image/png'));
 const report={passed:true,shards:128,fragment:'8x8 bitmap plus native INK/PAPER/BRIGHT',finishedAt,seconds:finishedAt/50,samples};
 fs.writeFileSync(path.join(__dirname,'out/intro-verification.json'),JSON.stringify(report,null,2));console.log(report);
}
run().catch(e=>{console.error(e);process.exitCode=1});
