$ErrorActionPreference = 'Stop'
$releaseRoot = $PSScriptRoot
$releaseStage = Join-Path $releaseRoot 'out/release-source'
$releaseWeb = Join-Path $releaseRoot 'dist'
$releaseFiles = @('README.md','package.json','index.html','style.css','player.js','serve.cjs','art.cjs','build.cjs','generate.cjs','music.cjs','verify.cjs','intro-test.cjs','tape-test.cjs','render-audio.cjs','package-release.ps1')
$releaseOutputs = Get-ChildItem (Join-Path $releaseRoot 'out') -File | Where-Object { $_.Name -match '^(attribute48\.(bin|tap|sna)|scene-\d+\.(png|scr|sna)|oracle\.(png|scr)|contact-sheet\.png|symbols\.txt|.*verification\.json|tape-boot\.json|assets\.json|music\.json|dark-intelligence-ay\.mp3)$' } | ForEach-Object { 'out/' + $_.Name }
function Copy-ReleaseItem([string]$Relative,[string]$Destination) {
    $releaseSource = Join-Path $releaseRoot $Relative
    if ((Get-Item -LiteralPath $releaseSource).PSIsContainer) {
        foreach ($releaseChild in (Get-ChildItem -LiteralPath $releaseSource -Recurse -File)) {
            if ($releaseChild.Name -ne '.DS_Store') {
                Copy-ReleaseItem ([System.IO.Path]::GetRelativePath($releaseRoot, $releaseChild.FullName)) $Destination
            }
        }
        return
    }
    $releaseTarget = Join-Path $Destination $Relative
    New-Item -ItemType Directory -Path (Split-Path $releaseTarget) -Force | Out-Null
    Copy-Item -LiteralPath $releaseSource -Destination $releaseTarget -Force
}
$releaseVendor = @('vendor/jsspeccy','vendor/COPYING-JSSpeccy','vendor/jsspeccy-3.2-source.zip')
foreach ($releaseItem in ($releaseFiles + @('src','assets') + $releaseVendor + $releaseOutputs)) { Copy-ReleaseItem $releaseItem $releaseStage }
foreach ($releaseItem in (@('README.md','index.html','style.css','player.js') + $releaseVendor + $releaseOutputs)) { Copy-ReleaseItem $releaseItem $releaseWeb }
$releaseZip = Join-Path $releaseRoot 'out/attribute48-source.zip'
Compress-Archive -Path (Join-Path $releaseStage '*') -DestinationPath $releaseZip -Force
Copy-ReleaseItem 'out/attribute48-source.zip' $releaseWeb
Set-Content -LiteralPath (Join-Path $releaseWeb '_headers') -Value "/vendor/jsspeccy/*.wasm`n  Content-Type: application/wasm" -Encoding utf8
Write-Output 'Source archive and static player are ready.'
