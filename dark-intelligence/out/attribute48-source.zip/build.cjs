'use strict';
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
function run(cmd,args,cwd=__dirname){const r=spawnSync(cmd,args,{cwd,stdio:'inherit',windowsHide:true});if(r.error)throw r.error;if(r.status!==0)process.exit(r.status||1)}
run(process.execPath,['art.cjs']);run(process.execPath,['music.cjs']);const bundled=path.join(__dirname,'tools/sjasmplus/sjasmplus-1.24.0.win/sjasmplus.exe'),assembler=process.env.SJASMPLUS||(fs.existsSync(bundled)?bundled:'sjasmplus');run(assembler,['--msg=war','--sym=../out/symbols.txt','--lst=../out/demo.lst','demo.asm'],path.join(__dirname,'src'));run(process.execPath,['verify.cjs']);run(process.execPath,['intro-test.cjs']);run(process.execPath,['tape-test.cjs']);
