'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),{createCanvas}=require('@napi-rs/canvas');
const root=__dirname,read=p=>fs.readFileSync(path.join(root,p));
const symbols=Object.fromEntries(read('out/symbols.txt').toString().trim().split(/\r?\n/).map(l=>{let m=l.match(/^(.*): EQU 0x([\dA-F]+)/i);return m?[m[1],parseInt(m[2],16)]:['',0]}));
const names=['Star drive','Sine plasma','Wave scroller','Vector cube','Polar tunnel','Rotozoom','Metaball fusion','Fractal dive','Voxel flight','Four dimensions','Recursive gates','Liquid chrome'];
async function makeCore(scene=0,withIntro=false){let {instance}=await WebAssembly.instantiate(read('vendor/jsspeccy/jsspeccy-core.wasm'),{}),c=instance.exports;
 c.setMachineType(48);c.reset();c.setTapeTraps(false);c.setAudioSamplesPerFrame(0);
 new Uint8Array(c.memory.buffer,Number(c.MACHINE_MEMORY)+10*16384,16384).set(read('vendor/jsspeccy/roms/48.rom'));
 const bin=read('out/attribute48.bin');for(let i=0;i<bin.length;i++)c.poke(symbols.start+i,bin[i]);c.poke(symbols.initial_scene+1,scene);c.poke(symbols.intro_enabled+1,withIntro?1:0);c.setPC(symbols.start);c.setIFF1(false);c.setIFF2(false);return c;
}
function step(c,n){for(let i=0;i<n;i++)assert.equal(c.runFrame(),0,'Z80 core status');}
function screen(c){return Buffer.from(Array.from({length:6912},(_,i)=>c.peek(0x4000+i)))}
function toCanvas(scr){let cv=createCanvas(256,192),ctx=cv.getContext('2d'),im=ctx.createImageData(256,192);
 for(let y=0;y<192;y++)for(let x=0;x<256;x++){let a=scr[6144+(y>>3)*32+(x>>3)],p=scr[((y&192)<<5)|((y&7)<<8)|((y&56)<<2)|(x>>3)],ink=(p>>(7-(x&7)))&1,col=ink?(a&7):((a>>3)&7),v=(a&64)?255:205,o=(y*256+x)*4;im.data[o]=(col&2)?v:0;im.data[o+1]=(col&4)?v:0;im.data[o+2]=(col&1)?v:0;im.data[o+3]=255;}ctx.putImageData(im,0,0);return cv;
}
async function verify(){let report={machine:'ZX Spectrum 48K',core:'JSSpeccy 3.2 WebAssembly',programBytes:read('out/attribute48.bin').length,tapBytes:read('out/attribute48.tap').length,scenes:[]};
 assert(symbols.program_end<0xf500);assert.equal(read('out/attribute48.sna').length,49179);
 const tap=read('out/attribute48.tap');let blocks=[],pos=0;while(pos<tap.length){let len=tap.readUInt16LE(pos);pos+=2;let b=tap.subarray(pos,pos+len);assert.equal(b.length,len);assert.equal(b.reduce((a,v)=>a^v,0),0,'TAP checksum');blocks.push(b);pos+=len}assert.equal(blocks.length,4);assert.equal(blocks[1][1],0);assert.equal(blocks[1][2],10);assert(blocks[1].includes(0xef),'LOAD token');assert(blocks[3].subarray(1,-1).equals(read('out/attribute48.bin')));
 let sheet=createCanvas(1024,720),ctx=sheet.getContext('2d');ctx.fillStyle='#101216';ctx.fillRect(0,0,1024,720);ctx.imageSmoothingEnabled=false;
 for(let i=0;i<12;i++){let c=await makeCore(i);step(c,180);assert.equal(c.peek(symbols.scene),i);let a=screen(c),before=c.peek(symbols.render_count);step(c,100);let b=screen(c),frames=(c.peek(symbols.render_count)-before)&255;assert(!a.equals(b),'Frozen scene '+i);assert(frames>3,'Render progress '+i);assert.equal(c.getIM(),2);assert.equal(c.peek(0xfe80),0xfd,'IM2 table intact');
  const image=toCanvas(b);fs.writeFileSync(path.join(root,'out',`scene-${String(i+1).padStart(2,'0')}.png`),image.toBuffer('image/png'));fs.writeFileSync(path.join(root,'out',`scene-${String(i+1).padStart(2,'0')}.scr`),b);
  let x=i%4*256,y=(i/4|0)*240;ctx.drawImage(image,x,y);ctx.fillStyle='#bbc0ce';ctx.font='13px Consolas';ctx.fillText(`${String(i+1).padStart(2,'0')} / ${names[i]}`,x+10,y+217);
  let snap=Buffer.from(read('out/attribute48.sna'));snap[27+symbols.initial_scene+1-16384]=i;snap[27+symbols.intro_enabled+1-16384]=0;fs.writeFileSync(path.join(root,'out',`scene-${String(i+1).padStart(2,'0')}.sna`),snap);
  report.scenes.push({scene:i+1,name:names[i],measuredFps:frames/2,pc:c.getPC(),ticks:c.peek(symbols.ticks)+256*c.peek(symbols.ticks+1)});
 }
 fs.writeFileSync(path.join(root,'out','contact-sheet.png'),sheet.toBuffer('image/png'));
 let c=await makeCore(0),seen=new Set(),looped=false;for(let i=0;i<7600;i++){step(c,1);let s=c.peek(symbols.scene);seen.add(s);if(seen.size===12&&s===0){looped=true;break}}assert.equal(seen.size,12,'Automatic sequence visits all scenes');assert(looped,'Automatic loop');
 c.keyDown(7,8);step(c,20);c.keyUp(7,8);assert.equal(c.peek(symbols.scene),1,'Native N key');step(c,20);let snd=c.peek(symbols.sound);c.keyDown(7,4);step(c,20);c.keyUp(7,4);assert.equal(c.peek(symbols.sound),snd^1,'Native AY mute key');
 report.passed=true;report.checks=['TAP block checksums and BASIC loader','48K RAM and SNA layout','12 moving scenes on Z80 core','Automatic full sequence and loop','Native next-scene and AY mute keys'];fs.writeFileSync(path.join(root,'out','verification.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}
if(require.main===module)verify().catch(e=>{console.error(e);process.exitCode=1});module.exports={makeCore,step,screen,toCanvas,symbols};
