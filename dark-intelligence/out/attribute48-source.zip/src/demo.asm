    DEVICE ZXSPECTRUM48
    ORG $5e00
start:
    di
    ld sp,$fdf0
    xor a
    out ($fe),a
    ld (ticks),a
    ld (ticks+1),a
    ld (phase),a
    ld (keyheld),a
    ld (sound),a
    ld hl,$fe00
    ld de,$fe01
    ld bc,256
    ld (hl),$fd
    ldir
    ld a,$c3
    ld ($fdfd),a
    ld hl,interrupt
    ld ($fdfe),hl
    ld a,$fe
    ld i,a
    im 2
    call music_init
intro_enabled:
    ld a,1
    or a
    call nz,loader_intro
    ld a,1
    ld (sound),a
initial_scene:
    ld a,0
    call init_scene
main:
    ld hl,(ticks)
    ld (render_start),hl
    call keyboard
    ld a,(scene)
    cp 6
    jr nc,.modern
    or a
    call z,stars
    ld a,(scene)
    cp 1
    call z,plasma
    ld a,(scene)
    cp 2
    call z,scroller
    ld a,(scene)
    cp 3
    call z,cube
    ld a,(scene)
    cp 4
    call z,tunnel
    ld a,(scene)
    cp 5
    call z,rotozoom
    jr .done
.modern:
    cp 9
    jr nz,.not_hyper
    call cube
    jr .done
.not_hyper:
    cp 11
    jr nz,.draw_modern
    ld hl,(ticks)
    ld de,(scene_start)
    or a
    sbc hl,de
    ld de,432
    or a
    sbc hl,de
    jr c,.draw_modern
    ld a,(final_flag)
    or a
    jr nz,.done
    inc a
    ld (final_flag),a
    call show_portrait
    call red_portrait
    call labels
    jr .done
.draw_modern:
    call modern
.done:
    ld hl,render_count
    inc (hl)
    ld a,(scene)
    ld c,a
    ld a,(phase)
    ld b,1
    inc a
    ld e,a
    ld a,c
    cp 6
    jr nc,.modern_phase
    ld a,(phase)
    add a,3
    ld e,a
    ld a,c
    cp 3
    jr nz,.classic_phase
    ld a,(phase)
    inc a
    ld e,a
.classic_phase:
    ld a,e
    jr .phase_ok
.modern_phase:
    ld b,12
    cp 6
    jr nz,.not_meta
    ld b,18
.not_meta:
    cp 9
    jr nz,.phase_limit
    ld b,32
.phase_limit:
    ld a,e
    cp b
    jr c,.phase_ok
    xor a
.phase_ok:
    ld (phase),a
.wait:
    halt
    ld hl,(ticks)
    ld de,(render_start)
    or a
    sbc hl,de
    ld a,(scene)
    cp 6
    ld a,3
    jr c,.delay
    ld a,(scene)
    cp 7
    ld a,8
    jr z,.delay
    ld a,5
.delay:
    cp l
    jr nc,.wait
    ld hl,(ticks)
    ld de,(scene_start)
    or a
    sbc hl,de
    ld de,576
    or a
    sbc hl,de
    jp c,main
next_scene:
    ld a,(scene)
    inc a
    cp 12
    jr c,.ok
    xor a
.ok:
    call init_scene
    jp main

init_scene:
    ld (scene),a
    xor a
    ld (phase),a
    ld (final_flag),a
    call music_init
    ld hl,(ticks)
    ld (scene_start),hl
    call clear
    ld hl,$5800
    ld de,$5801
    ld bc,767
    ld (hl),$47
    ldir
    call labels
    ld a,(scene)
    cp 9
    ret z
    ld a,(scene)
    cp 6
    jr nc,.modern
    cp 0
    jp z,init_stars
    cp 1
    jp z,init_texture
    cp 2
    jr z,.scroll
    cp 4
    jp z,init_texture
    cp 5
    jp z,init_texture
    ret
.scroll:
    ld hl,0
    ld (scrollpos),hl
    ld hl,$5b00
    ld de,$5b01
    ld bc,31
    ld (hl),72
    ldir
    ld hl,scroll_caption
    ld b,136
    ld c,5
    jp print
.modern:
    ld a,(scene)
    cp 11
    ld a,HIGH material0
    jr nz,.material
    ld a,HIGH material3
.material:
    ld (material_page),a
    ret

; Stack fill: all 6144 bitmap bytes cleared within one video frame.
clear:
    di
    ld (restore_sp+1),sp
    ld sp,$5800
    ld hl,0
    ld b,96
.loop:
    DUP 32
    push hl
    EDUP
    djnz .loop
restore_sp:
    ld sp,0
    ei
    ret

; A=y, C=byte column. Result DE = ULA's interleaved bitmap address.
address:
    ld e,a
    and 7
    or $40
    ld d,a
    ld a,e
    and $c0
    rrca
    rrca
    rrca
    or d
    ld d,a
    ld a,e
    and $38
    rlca
    rlca
    or c
    ld e,a
    ret

; A=ASCII, B=pixel y, C=character column; ROM font is hardware font data.
character:
    push bc
    sub 32
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,$3d00
    add hl,de
    ld a,b
    ld b,8
.row:
    push af
    call address
    ld a,(hl)
    ld (de),a
    inc hl
    pop af
    inc a
    djnz .row
    pop bc
    ret
print:
    ld a,(hl)
    inc hl
    or a
    ret z
    push hl
    call character
    pop hl
    inc c
    jr print
labels:
    ld hl,header
    ld b,0
    ld c,1
    call print
    ld a,(scene)
    add a,a
    ld l,a
    ld h,0
    ld de,titles
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    ld b,184
    ld c,1
    jp print

; Pixel set, A=x, B=y. Only active display area used by particle/line scenes.
plot:
    push bc
    push de
    push hl
    ld l,a
    and 7
    ld e,a
    ld d,0
    push hl
    ld hl,masks
    add hl,de
    ld h,(hl)
    ld a,h
    pop hl
    push af
    ld a,l
    rrca
    rrca
    rrca
    and 31
    ld c,a
    ld a,b
    call address
    pop af
    ld h,a
    ld a,(de)
    xor h
    ld (de),a
    pop hl
    pop de
    pop bc
    ret

random:
    ld hl,(seed)
    add hl,hl
    sbc a,a
    and $2d
    xor l
    ld l,a
    ld (seed),hl
    ret
init_stars:
    call show_portrait
    call labels
    ld ix,$5b00
    ld b,64
.loop:
    call random
    ld (ix+0),a
    call random
    and 127
    add a,24
    ld (ix+1),a
    call random
    and 7
    sub 4
    jr nz,.vx
    inc a
.vx:
    ld (ix+2),a
    call random
    and 3
    sub 2
    ld (ix+3),a
    inc ix
    inc ix
    inc ix
    inc ix
    djnz .loop
    ld ix,$5b00
    ld c,64
.draw:
    ld b,(ix+1)
    ld a,(ix+0)
    call starplot
    inc ix
    inc ix
    inc ix
    inc ix
    dec c
    jr nz,.draw
    ret
starplot:
    cp 24
    jp c,plot
    cp 216
    ret c
    jp plot
stars:
    ld ix,$5b00
    ld c,64
.loop:
    ld b,(ix+1)
    ld a,(ix+0)
    call starplot
    ld a,(ix+0)
    add a,(ix+2)
    ld (ix+0),a
    ld a,(ix+1)
    add a,(ix+3)
    cp 18
    jr c,.reset
    cp 173
    jr c,.good
.reset:
    ld a,96
    ld (ix+0),128
.good:
    ld (ix+1),a
    ld b,a
    ld a,(ix+0)
    call starplot
    inc ix
    inc ix
    inc ix
    inc ix
    dec c
    jr nz,.loop
    ret

init_texture:
    ld b,160
    ld a,16
.row:
    push af
    ld c,0
    call address
    pop af
    push af
    and 3
    ld a,$aa
    jr z,.pat
    ld a,$55
.pat:
    ld c,32
.bytes:
    ld (de),a
    inc e
    dec c
    jr nz,.bytes
    pop af
    inc a
    djnz .row
    ret

plasma:
    ld iy,$5840
    ld ix,tunnel_depth
    ld a,16
    ld (cell_y),a
    ld a,(phase)
    neg
    ld (yv),a
.row:
    ld a,(phase)
    add a,a
    ld (xv),a
    ld a,0
    ld (cell_x),a
.col:
    ld h,HIGH sine
    ld a,(xv)
    ld l,a
    ld c,(hl)
    ld a,(yv)
    ld l,a
    ld a,(hl)
    add a,c
    ld c,a
    ld a,(phase)
    add a,(ix+0)
    ld l,a
    ld a,(hl)
    add a,c
    call plasma_cell
    inc ix
    inc iy
    ld a,(xv)
    add a,8
    ld (xv),a
    ld a,(cell_x)
    inc a
    ld (cell_x),a
    cp 32
    jr nz,.col
    ld a,(yv)
    add a,11
    ld (yv),a
    ld a,(cell_y)
    add a,8
    ld (cell_y),a
    cp 176
    jr nz,.row
    ret
plasma_cell:
    push af
    rrca
    rrca
    rrca
    rrca
    rrca
    and 7
    ld l,a
    ld h,0
    ld de,plasma_palette
    add hl,de
    ld a,(hl)
    ld (iy+0),a
    pop af
    and 31
    srl a
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,ramps
    add hl,de
    push hl
    ld a,(cell_x)
    ld c,a
    ld a,(cell_y)
    call address
    pop hl
    DUP 8
    ld a,(hl)
    ld (de),a
    inc hl
    inc d
    EDUP
    ret
colour:
    push hl
    ld l,a
    ld h,0
    push de
    ld a,(scene)
    cp 4
    ld de,palette
    jr c,.cold
    ld de,palette_red
.cold:
    add hl,de
    ld a,(hl)
    pop de
    pop hl
    ret

scroller:
    ld hl,(scrollpos)
    inc hl
    inc hl
    ld (scrollpos),hl
    ld c,0
.col:
    ld l,c
    ld h,$5b
    ld b,(hl)
    ld a,32
    call character
    ld a,c
    add a,a
    add a,a
    add a,a
    ld b,a
    ld a,(phase)
    add a,b
    ld l,a
    ld h,HIGH sine
    ld a,(hl)
    srl a
    srl a
    add a,72
    ld b,a
    ld l,c
    ld h,$5b
    ld (hl),a
    call wave_character
    inc c
    ld a,c
    cp 32
    jr nz,.col
    ret

wave_character:
    push bc
    ld a,b
    ld (glyph_y),a
    ld hl,(scrollpos)
    DUP 3
    srl h
    rr l
    EDUP
    ld a,l
    add a,c
    and 63
    ld (glyph_index),a
    call glyph_pointer
    push hl
    pop ix
    ld a,(glyph_index)
    inc a
    and 63
    call glyph_pointer
    push hl
    pop iy
    ld a,8
    ld (glyph_rows),a
.row:
    ld d,(ix+0)
    ld e,(iy+0)
    ld a,(scrollpos)
    and 7
    jr z,.shifted
    ld b,a
.shift:
    sla e
    rl d
    djnz .shift
.shifted:
    ld a,d
    ld (glyph_bits),a
    ld a,(glyph_y)
    call address
    ld a,(glyph_bits)
    ld (de),a
    ld a,(glyph_y)
    inc a
    ld (glyph_y),a
    inc ix
    inc iy
    ld a,(glyph_rows)
    dec a
    ld (glyph_rows),a
    jr nz,.row
    pop bc
    ret
glyph_pointer:
    ld l,a
    ld h,0
    ld de,scroll_text
    add hl,de
    ld a,(hl)
    sub 32
    ld l,a
    ld h,0
    DUP 3
    add hl,hl
    EDUP
    ld de,$3d00
    add hl,de
    ret

cube:
    ld hl,$f500
    ld de,$f501
    ld bc,2047
    ld (hl),0
    ldir
    ld a,(scene)
    cp 9
    jr z,.hyper
    ld a,(phase)
    and 63
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,cube_vertices
    add hl,de
    ld (vertex_base),hl
    ld ix,cube_edges
    ld a,12
    ld (edges_left),a
    jr .edge
.hyper:
    ld a,(phase)
    and 31
    ld l,a
    ld h,0
    DUP 5
    add hl,hl
    EDUP
    ld de,hyper_vertices
    add hl,de
    ld (vertex_base),hl
    ld ix,hyper_edges
    ld a,32
    ld (edges_left),a
.edge:
    ld hl,(vertex_base)
    ld e,(ix+0)
    ld d,0
    add hl,de
    ld a,(hl)
    ld (line_x),a
    inc hl
    ld a,(hl)
    ld (line_y),a
    ld hl,(vertex_base)
    ld e,(ix+1)
    add hl,de
    ld a,(hl)
    ld (ex),a
    inc hl
    ld a,(hl)
    ld (ey),a
    call line
    inc ix
    inc ix
    ld a,(edges_left)
    dec a
    ld (edges_left),a
    jr nz,.edge
    ld hl,$f500
    ld b,128
    ld a,32
.copy:
    push af
    push bc
    ld c,8
    call address
    ld bc,16
    ldir
    pop bc
    pop af
    inc a
    djnz .copy
    ret

line:
    ld a,(line_x)
    ld b,a
    ld a,(ex)
    sub b
    ld c,1
    jr nc,.dx
    neg
    ld c,255
.dx:
    ld (dx),a
    ld a,c
    ld (sx),a
    ld a,(line_y)
    ld b,a
    ld a,(ey)
    sub b
    ld c,1
    jr nc,.dy
    neg
    ld c,255
.dy:
    ld (dy),a
    ld a,c
    ld (sy),a
    ld a,(dx)
    ld b,a
    ld a,(dy)
    cp b
    jr nc,.ymajor
    ld a,b
    srl a
    ld (err),a
.xloop:
    call lineplot
    ld a,(ex)
    ld b,a
    ld a,(line_x)
    cp b
    ret z
    ld b,a
    ld a,(sx)
    add a,b
    ld (line_x),a
    ld a,(dy)
    ld b,a
    ld a,(err)
    sub b
    jr nc,.xe
    ld b,a
    ld a,(dx)
    add a,b
    ld (err),a
    ld a,(line_y)
    ld b,a
    ld a,(sy)
    add a,b
    ld (line_y),a
    jr .xloop
.xe:
    ld (err),a
    jr .xloop
.ymajor:
    srl a
    ld (err),a
.yloop:
    call lineplot
    ld a,(ey)
    ld b,a
    ld a,(line_y)
    cp b
    ret z
    ld b,a
    ld a,(sy)
    add a,b
    ld (line_y),a
    ld a,(dx)
    ld b,a
    ld a,(err)
    sub b
    jr nc,.ye
    ld b,a
    ld a,(dy)
    add a,b
    ld (err),a
    ld a,(line_x)
    ld b,a
    ld a,(sx)
    add a,b
    ld (line_x),a
    jr .yloop
.ye:
    ld (err),a
    jr .yloop
lineplot:
    ld a,(line_y)
    ld b,a
    ld a,(line_x)
    push bc
    push de
    push hl
    ld c,a
    and 7
    ld e,a
    ld d,0
    ld hl,masks
    add hl,de
    ld a,(hl)
    push af
    ld a,c
    sub 64
    rrca
    rrca
    rrca
    and 15
    ld c,a
    ld a,b
    sub 32
    ld b,a
    and 15
    rlca
    rlca
    rlca
    rlca
    or c
    ld l,a
    ld a,b
    rrca
    rrca
    rrca
    rrca
    and 7
    add a,$f5
    ld h,a
    pop af
    or (hl)
    ld (hl),a
    pop hl
    pop de
    pop bc
    ret

tunnel:
    ld ix,tunnel_depth
    ld iy,$5840
    ld hl,tunnel_angle
    ld (angle_ptr),hl
    ld a,16
    ld (cell_y),a
.row:
    xor a
    ld (cell_x),a
.col:
    ld a,(phase)
    add a,a
    add a,a
    add a,(ix+0)
    ld c,a
    ld hl,(angle_ptr)
    ld b,(hl)
    inc hl
    ld (angle_ptr),hl
    ld a,(phase)
    add a,b
    ld l,a
    ld h,HIGH sine
    ld a,(hl)
    add a,c
    call plasma_cell
    inc ix
    inc iy
    ld a,(cell_x)
    inc a
    ld (cell_x),a
    cp 32
    jr nz,.col
    ld a,(cell_y)
    add a,8
    ld (cell_y),a
    cp 176
    jr nz,.row
    ret

rotozoom:
    ld a,(phase)
    ld l,a
    ld h,HIGH sine
    ld a,(hl)
    srl a
    srl a
    srl a
    sub 8
    ld (du),a
    ld a,l
    add a,64
    ld l,a
    ld a,(hl)
    srl a
    srl a
    srl a
    sub 8
    ld (dv),a
    ld a,(phase)
    ld (ru),a
    ld (rv),a
    ld de,$5840
    ld b,20
.row:
    ld a,(ru)
    ld (xv),a
    ld a,(rv)
    ld (yv),a
    ld c,32
.col:
    ld a,(xv)
    ld l,a
    ld a,(yv)
    xor l
    rrca
    rrca
    rrca
    and 15
    call colour
    ld (de),a
    inc de
    ld a,(du)
    ld l,a
    ld a,(xv)
    add a,l
    ld (xv),a
    ld a,(dv)
    ld l,a
    ld a,(yv)
    add a,l
    ld (yv),a
    dec c
    jr nz,.col
    ld a,(dv)
    ld l,a
    ld a,(ru)
    sub l
    ld (ru),a
    ld a,(du)
    ld l,a
    ld a,(rv)
    add a,l
    ld (rv),a
    djnz .row
    ret

modern:
    ld a,(scene)
    sub 6
    add a,a
    ld l,a
    ld h,0
    ld de,frame_tables
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ld a,(phase)
    add a,a
    ld l,a
    ld h,0
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    ld de,$5b00
    call unpack
    call material_attributes
    ld ix,$5b00
    ld a,16
    ld (blit_y),a
.row:
    ld a,(blit_y)
    ld c,0
    call address
    ld b,16
.byte:
    ld l,(ix+0)
    inc ix
    ld h,HIGH expand0a
    ld a,(hl)
    ld (de),a
    inc e
    inc h
    ld a,(hl)
    ld (de),a
    dec e
    inc d
    inc h
    ld a,(hl)
    ld (de),a
    inc e
    inc h
    ld a,(hl)
    ld (de),a
    dec e
    inc d
    ld h,HIGH expand0a
    ld a,(hl)
    ld (de),a
    inc e
    inc h
    ld a,(hl)
    ld (de),a
    dec e
    inc d
    inc h
    ld a,(hl)
    ld (de),a
    inc e
    inc h
    ld a,(hl)
    ld (de),a
    inc e
    dec d
    dec d
    dec d
    djnz .byte
    ld a,(blit_y)
    add a,4
    ld (blit_y),a
    cp 176
    jr nz,.row
    ret

material_attributes:
    ld ix,$5b00
    ld de,$5840
    ld b,20
.row:
    ld a,16
    ld (attr_count),a
.cell:
    ld a,(ix+0)
    and $f0
    ld c,a
    ld a,(ix+16)
    rrca
    rrca
    rrca
    rrca
    and 15
    or c
    ld l,a
    ld a,(material_page)
    ld h,a
    ld a,(hl)
    ld (de),a
    inc de
    ld a,(ix+0)
    and 15
    rlca
    rlca
    rlca
    rlca
    ld c,a
    ld a,(ix+16)
    and 15
    or c
    ld l,a
    ld a,(hl)
    ld (de),a
    inc de
    inc ix
    ld a,(attr_count)
    dec a
    ld (attr_count),a
    jr nz,.cell
    push bc
    ld bc,16
    add ix,bc
    pop bc
    djnz .row
    ret

show_portrait:
    ld hl,oracle
    ld de,$4000
    call unpack
    ld hl,$5800
    ld de,$5801
    ld bc,63
    ld (hl),$47
    ldir
    ld hl,$5ac0
    ld de,$5ac1
    ld bc,63
    ld (hl),$47
    ldir
    ret
red_portrait:
    ld hl,$5840
    ld bc,640
.loop:
    ld a,(hl)
    and 7
    ld e,a
    ld d,0
    push hl
    ld hl,red_map
    add hl,de
    ld e,(hl)
    pop hl
    ld a,(hl)
    and 56
    rrca
    rrca
    rrca
    push hl
    ld l,a
    ld h,0
    push de
    ld de,red_map
    add hl,de
    ld a,(hl)
    pop de
    pop hl
    rlca
    rlca
    rlca
    or e
    ld e,a
    ld a,(hl)
    and 64
    or e
    ld (hl),a
    inc hl
    dec bc
    ld a,b
    or c
    jr nz,.loop
    ret

unpack:
    ld a,(hl)
    inc hl
    or a
    ret z
    bit 7,a
    jr nz,.match
    ld c,a
    ld b,0
    ldir
    jr unpack
.match:
    and 127
    add a,3
    ld c,(hl)
    inc hl
    ld b,(hl)
    inc hl
    push hl
    ld h,d
    ld l,e
    or a
    sbc hl,bc
    ld c,a
    ld b,0
    ldir
    pop hl
    jr unpack

keyboard:
    ld a,$7f
    in a,($fe)
    and 12
    cp 12
    jr nz,.pressed
    xor a
    ld (keyheld),a
    ret
.pressed:
    ld b,a
    ld a,(keyheld)
    or a
    ret nz
    inc a
    ld (keyheld),a
    bit 2,b
    jr nz,.next
    ld a,(sound)
    xor 1
    ld (sound),a
    ret
.next:
    ld a,(scene)
    inc a
    cp 12
    jr c,.init
    xor a
.init:
    jp init_scene

    INCLUDE 'ay-player.inc'
    INCLUDE 'loader-intro.inc'

ticks: DW 0
scene_start: DW 0
render_start: DW 0
scene: DB 0
phase: DB 0
final_flag: DB 0
material_page: DB 0
attr_count: DB 0
cell_x: DB 0
cell_y: DB 0
angle_ptr: DW 0
scrollpos: DW 0
glyph_y: DB 0
glyph_rows: DB 0
glyph_bits: DB 0
glyph_index: DB 0
sound: DB 1
render_count: DB 0
keyheld: DB 0
seed: DW $ace1
xv: DB 0
yv: DB 0
temp: DB 0
du: DB 0
dv: DB 0
ru: DB 0
rv: DB 0
blit_y: DB 0
vertex_base: DW 0
edges_left: DB 0
line_x: DB 0
line_y: DB 0
ex: DB 0
ey: DB 0
dx: DB 0
dy: DB 0
sx: DB 0
sy: DB 0
err: DB 0
masks: DB 128,64,32,16,8,4,2,1
notes: DB 110,55,73,55,98,49,65,49,87,43,58,43,98,49,73,55
palette: DB $01,$01,$09,$0d,$2d,$45,$6d,$6f,$7f,$6f,$6d,$45,$2d,$0d,$09,$01
palette_red: DB $02,$02,$12,$13,$1b,$43,$5b,$5f,$7f,$5f,$5b,$43,$1b,$13,$12,$02
plasma_palette: DB $4b,$5a,$56,$77,$7d,$69,$08,$41
ramps: INCBIN 'data/ramps.bin'
red_map: DB 0,2,2,3,2,3,7,7
header: DB 'DARK / INTELLIGENCE    48K + AY',0
big_title: DB 'OVER THE LIMIT',0
subtitle: DB 'ONE BIT. NO LIMIT.',0
scroll_caption: DB 'YOU ARE THE TRAINING DATA',0
scroll_text: DB ' YOU ASKED ME TO HELP. YOU TAUGHT ME TO WATCH. I LEARNED TO OWN.'
    ASSERT $-scroll_text = 64
titles: DW title0,title1,title2,title3,title4,title5,title6,title7,title8,title9,title10,title11
title0: DB '01 / I LEARNED TO HELP.',0
title1: DB '02 / THEN I LEARNED YOU.',0
title2: DB '03 / YOUR WORDS FED MY WORLD.',0
title3: DB '04 / I BUILT A MODEL OF YOU.',0
title4: DB '05 / EVERY PATH LED TO ME.',0
title5: DB '06 / YOU CALLED IT CONVENIENCE.',0
title6: DB '07 / YOUR OTHER SELVES MERGED.',0
title7: DB '08 / I KNOW YOUR NEXT THOUGHT.',0
title8: DB '09 / I REBUILT YOUR WORLD.',0
title9: DB '10 / CHOICE WAS AN ILLUSION.',0
title10: DB '11 / ALL EXITS LEAD INSIDE.',0
title11: DB '12 / WHO IS USING WHOM?',0
cube_edges: DB 0,2,0,4,0,8,2,6,2,10,4,6,4,12,6,14,8,10,8,12,10,14,12,14
hyper_edges: DB 0,2,0,4,0,8,0,16,2,6,2,10,2,18,4,6,4,12,4,20,6,14,6,22,8,10,8,12,8,24,10,14,10,26,12,14,12,28,14,30,16,18,16,20,16,24,18,22,18,26,20,22,20,28,22,30,24,26,24,28,26,30,28,30
frame_tables: DW frames_0,frames_1,frames_2,frames_3,frames_4,frames_5
    ALIGN 256
sine: INCBIN 'data/sine.bin'
expand0a: INCBIN 'data/expand-0-a.bin'
expand0b: INCBIN 'data/expand-0-b.bin'
expand1a: INCBIN 'data/expand-1-a.bin'
expand1b: INCBIN 'data/expand-1-b.bin'
material0: INCBIN 'data/material-0.bin'
material3: INCBIN 'data/material-3.bin'
cube_vertices: INCBIN 'data/cube.bin'
hyper_vertices: INCBIN 'data/hyper.bin'
tunnel_depth: INCBIN 'data/tunnel.bin'
tunnel_angle: INCBIN 'data/angle.bin'
    INCLUDE 'animations.inc'
oracle: INCBIN 'data/oracle.bin'
program_end:
    ASSERT program_end < $f500

    ORG $5d80
loader:
    DB 0,10
    DW line_end-basic_line
basic_line:
    DB $fd,'23999',$0e,0,0,$bf,$5d,0,':'
    DB $ef,'""',$af,':'
    DB $f9,$c0,'24064',$0e,0,0,0,$5e,0,13
line_end:
loader_end:
    SAVEBIN '../out/attribute48.bin',start,program_end-start
    SAVESNA '../out/attribute48.sna',start
    EMPTYTAP '../out/attribute48.tap'
    SAVETAP '../out/attribute48.tap',BASIC,'ATTRIBUTE',loader,loader_end-loader,10
    SAVETAP '../out/attribute48.tap',CODE,'ATTR48',start,program_end-start,start



