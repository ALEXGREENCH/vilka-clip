'use strict';
// Original score: THE BENEVOLENT MACHINE. D minor / Phrygian b2 tension,
// martial ostinato, a rising chromatic middle act, unresolved ending.
const fs=require('fs'),path=require('path'),root=__dirname;
const lead=[
[62,0,0,0,69,0,65,0,64,0,0,0,63,0,62,0],
[62,0,65,0,69,0,70,69,67,0,65,64,63,0,0,0],
[58,0,0,58,65,0,62,0,60,0,62,0,57,0,0,0],
[61,0,64,0,67,0,70,0,73,72,70,67,64,0,61,0],
[74,0,0,69,72,0,70,0,69,0,65,0,63,64,62,0],
[63,0,66,0,69,0,72,0,71,0,69,0,66,0,63,0],
[62,65,69,65,63,66,70,66,64,67,71,67,65,68,72,68],
[74,0,73,0,70,0,67,0,64,0,61,0,62,0,0,0],
[62,0,62,0,63,0,0,0,69,0,65,0,64,63,62,0],
[65,0,0,0,64,0,0,0,63,0,0,0,61,0,0,0],
[74,0,77,0,81,0,82,81,79,0,77,76,75,0,74,0],
[62,0,0,0,63,0,0,0,61,0,0,0,62,0,0,0]
];
const roots=[38,38,34,37,38,39,38,37,38,34,38,38];let asm=['note_periods:'];let periods=Array.from({length:96},(_,m)=>Math.min(4095,Math.round(1773400/(16*440*2**((m-69)/12)))));asm.push(' DW '+periods.join(','));let ptr=[];
for(let p=0;p<12;p++){ptr.push(`pattern_${p}`);asm.push(`pattern_${p}:`);for(let i=0;i<16;i++){let bass=i%4===0?roots[p]:i%4===2?roots[p]+7:0,arp=[0,7,12,3][i%4]+roots[p]+12,drum=i%8===0?1:i%8===4?2:i%2===1?3:0;if(p===9||p===11)arp=i%2?0:arp;asm.push(' DB '+[lead[p][i],bass,arp,drum].join(','))}}
asm.push('pattern_table: DW '+ptr.join(','));let order=[];for(let s=0;s<12;s++)order.push(...[s,(s+1)%12,s,(s+2)%12,s,(s+3)%12]);asm.push('song_order: DB '+order.join(','));fs.writeFileSync(path.join(root,'src/music.inc'),asm.join('\n')+'\n');fs.writeFileSync(path.join(root,'out/music.json'),JSON.stringify({title:'The Benevolent Machine',composer:'Original generated composition for this demo',chip:'AY-3-8912, 1.7734 MHz, ABC',bpm:125,rowsPerBeat:4,ticksPerRow:6,bars:72,durationNominal:138.24,method:'Z80 IM2 interrupt; three tone voices plus time-shared noise percussion; standard FFFD/BFFD ports',reference:'Space-opera tension and martial orchestration; no quoted Star Wars melody'},null,2));console.log('AY score:',12*64+192+24+72,'bytes plus player');
