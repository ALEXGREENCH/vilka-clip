'use strict';
// Build-time artwork. No JavaScript graphics run in the player: the Z80 decodes
// these compact 2-bit samples and draws every visible pixel into Spectrum RAM.
const fs=require('fs'),path=require('path');
const dir=__dirname, out=path.join(dir,'src','data');fs.mkdirSync(out,{recursive:true});
const W=64,H=40,FRAMES=12,TAU=Math.PI*2;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const norm=v=>{const l=Math.hypot(...v);return v.map(x=>x/l)};
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const rot=(v,a,b)=>{let [x,y,z]=v;let X=x*Math.cos(a)+z*Math.sin(a),Z=z*Math.cos(a)-x*Math.sin(a);return [X,y*Math.cos(b)-Z*Math.sin(b),Z*Math.cos(b)+y*Math.sin(b)]};
function pack(values){const b=Buffer.alloc(W*H/4);for(let i=0;i<values.length;i++)b[i>>2]|=Math.round(clamp(values[i])*3)<<((3-(i&3))*2);return b}
// Simple bounded LZ: 0=end, 1..127=literal run, 128..255=3..130
// byte back-reference followed by a 16-bit little endian distance.
function compress(raw){let out=[],lit=[],dict=new Map();
 const flush=()=>{if(lit.length){out.push(lit.length,...lit);lit=[]}};
 const add=i=>{if(i+2>=raw.length)return;let k=(raw[i]<<16)|(raw[i+1]<<8)|raw[i+2],q=dict.get(k)||[];q.push(i);if(q.length>64)q.shift();dict.set(k,q)};
 for(let i=0;i<raw.length;){let len=0,dist=0,k=(raw[i]<<16)|(raw[i+1]<<8)|raw[i+2],q=dict.get(k)||[];
 for(let n=q.length-1;n>=0;n--){let j=q[n],l=0;while(l<130&&i+l<raw.length&&raw[j+l]===raw[i+l])l++;if(l>len){len=l;dist=i-j}if(l===130)break}
 if(len>=4){flush();out.push(128+len-3,dist&255,dist>>8);for(let n=0;n<len;n++)add(i+n);i+=len}else{lit.push(raw[i]);add(i++);if(lit.length===127)flush()}}
 flush();out.push(0);return Buffer.from(out)}
function decompress(src){let out=[];for(let i=0;i<src.length;){let c=src[i++];if(!c)break;if(c<128){for(let j=0;j<c;j++)out.push(src[i++])}else{let d=src[i++]|src[i++]<<8;for(let j=0;j<(c&127)+3;j++)out.push(out[out.length-d])}}return Buffer.from(out)}
// Each frame compressed independently, so no history buffer or hidden RAM.
const light=norm([-.6,-.7,1]);
function metaballs(x,y,t){
 const centers=[[Math.sin(t)*.43,Math.cos(t)*.21,.34],[Math.sin(t+2.1)*.5,Math.cos(t+2.1)*.3,.28],[Math.sin(t+4.2)*.44,Math.cos(t+4.2)*.28,.3]];
 let f=0,gx=0,gy=0;for(const[a,b,r]of centers){let dx=x-a,dy=y-b,d=dx*dx+dy*dy+.035;f+=r*r/d;gx+=r*r*dx/d**2;gy+=r*r*dy/d**2}if(f<1.25)return .02;
 let n=norm([gx,gy,Math.sqrt(Math.max(.001,f-1.25))*5]),d=clamp(dot(n,light));return .15+d*.6+Math.pow(d,16)*.25;
}
function mandel(x,y,t){
 const zoom=1.7+1.3*Math.sin(t),a=Math.sin(t)*.3,X=(x*Math.cos(a)-y*Math.sin(a))/zoom-.72,Y=(x*Math.sin(a)+y*Math.cos(a))/zoom+.17;
 let u=0,v=0,i=0;for(;i<30&&u*u+v*v<32;i++){let q=u*u-v*v+X;v=2*u*v+Y;u=q}return i===30?0:(.2+(i%9)/11);
}
function landscape(x,y,t){
 const rayY=-y*.65-.12;for(let z=.6;z<24;z+=.16){let X=x*z*.8+Math.sin(t)*.3,Z=z+t,tower=z>6&&Math.sin(Math.floor(X)*2.9)+Math.cos(Z*2)>1.45,h=(Math.sin(X*.7)+Math.cos(Z)+Math.sin(X*.4+Z))*.35+(tower?1.5:0);
 if(1.3+rayY*z<h){let nx=-(.245*Math.cos(X*.7)+.14*Math.cos(X*.4+Z)),nz=.35*Math.sin(Z)+.35*Math.cos(X*.4+Z),n=norm([nx,1,nz]);return tower?.3+.4*(X-Math.floor(X)):clamp(.15+dot(n,norm([-.4,1,-.7]))*.67-z*.012)}}let moon=Math.hypot(x-.6,y+.48);if(moon<.21)return .63+.37*(x-.39)/.42;return Math.sin(x*311+y*723)> .997&&y<-.28?.7:0;
}
function chrome(x,y,t){
 const R=.63,r=.22,px=x*(1+.06*Math.sin(t)),py=y+.10*Math.sin(t),q=Math.hypot(px,py),d=q-R;if(Math.abs(d)>r)return 0;
 const z=Math.sqrt(r*r-d*d),n=norm([px/q*d,py/q*d,z]);let a=Math.atan2(n[0],n[2])+t,b=n[1]*2;
 let bands=Math.sin(a*7+b*4),shine=Math.pow(clamp(dot(n,light)),14);return clamp(.22+bands*.28+shine*.8+Math.sin(a*3-b*5)*.14);
}
function line(buf,x0,y0,x1,y1,value=1){let n=Math.ceil(Math.max(Math.abs(x1-x0),Math.abs(y1-y0)));for(let i=0;i<=n;i++){let u=n?i/n:0,x=Math.round(x0+(x1-x0)*u),y=Math.round(y0+(y1-y0)*u);if(x>=0&&x<W&&y>=0&&y<H)buf[y*W+x]=Math.max(value,buf[y*W+x])}}
function hyper(t){let b=new Float32Array(W*H),p=[];for(let i=0;i<16;i++){let v=[0,1,2,3].map(k=>(i>>k&1)?1:-1),a=v[0]*Math.cos(t)-v[3]*Math.sin(t),w=v[3]*Math.cos(t)+v[0]*Math.sin(t);v[0]=a;let f=2/(3-w);v=rot(v.slice(0,3).map(x=>x*f),t*.5,.45);let d=3.6-v[2];p.push([32+v[0]*29/d,20+v[1]*29/d,v[2]])}
 for(let i=0;i<16;i++)for(let k=0;k<4;k++){let j=i^(1<<k);if(j>i)line(b,...p[i].slice(0,2),...p[j].slice(0,2),.6+(p[i][2]+1.5)*.1)}return b}
function portals(t){let b=new Float32Array(W*H);for(let i=15;i>=0;i--){let z=i,s=33*Math.pow(.83,z)*(1+.08*Math.sin(t)),a=z*.16+t,cx=32+Math.sin(z*.32+t)*z*.42,cy=20+Math.cos(z*.3+t)*z*.25,p=[];for(let j=0;j<4;j++){let A=a+Math.PI/4+j*Math.PI/2;p.push([cx+Math.cos(A)*s,cy+Math.sin(A)*s])}for(let j=0;j<4;j++)line(b,...p[j],...p[(j+1)%4],.45+(15-i)/30)}return b}
const effects=[['METABALLS',metaballs],['FRACTAL DIVE',mandel],['VOXEL FLIGHT',landscape],['FOUR DIMENSIONS',hyper],['RECURSIVE GATES',portals],['LIQUID CHROME',chrome]];
let report=[],asm=[];
for(let e=0;e<effects.length;e++){let [name,fn]=effects[e],pointers=[],count=e===3?0:e===0?18:FRAMES;for(let f=0;f<count;f++){let t=f/count*TAU,b;
 if(e===3||e===4)b=fn(t);else{b=new Float32Array(W*H);for(let y=0;y<H;y++)for(let x=0;x<W;x++)b[y*W+x]=fn((x-31.5)/26,(y-19.5)/22,t)}
 let raw=pack(b),zip=compress(raw);if(!decompress(zip).equals(raw))throw Error('LZ roundtrip');let file=`modern-${e}-${f}.bin`;fs.writeFileSync(path.join(out,file),zip);pointers.push(`modern_${e}_${f}`);asm.push(`modern_${e}_${f}: INCBIN "data/${file}"`);report.push({effect:name,frame:f,bytes:zip.length});}
 asm.unshift(`frames_${e}: DW ${pointers.length?pointers.join(','):'0'}`);
}
fs.writeFileSync(path.join(dir,'src','animations.inc'),asm.join('\n')+'\n');
// One material LUT per scene. Each entry describes all four 4x4 luminance
// samples sharing ONE 8x8 attribute. INK and PAPER therefore follow the object.
for(let e=0;e<6;e++){let colours=e>=3&&e!==4?[0,2,3,7]:[0,1,5,7],lut=Buffer.alloc(256);for(let i=0;i<256;i++){let s=[i>>6,(i>>4)&3,(i>>2)&3,i&3],lo=Math.min(...s),hi=Math.max(...s),paper=colours[Math.min(lo,Math.max(0,hi-1))],ink=colours[hi];lut[i]=(hi===3?64:0)|(paper<<3)|ink}fs.writeFileSync(path.join(out,`material-${e}.bin`),lut)}
let sine=Buffer.from(Array.from({length:256},(_,i)=>Math.round(64+63*Math.sin(i*TAU/256))));fs.writeFileSync(path.join(out,'sine.bin'),sine);
let tunnel=Buffer.alloc(640),angle=Buffer.alloc(640);for(let y=0;y<20;y++)for(let x=0;x<32;x++){let i=y*32+x,dx=x-15.5,dy=(y-9.5)*1.25;tunnel[i]=(250/(Math.hypot(dx,dy)+.7))&255;angle[i]=(Math.atan2(dy,dx)*128/Math.PI)&255}fs.writeFileSync(path.join(out,'tunnel.bin'),tunnel);fs.writeFileSync(path.join(out,'angle.bin'),angle);
// 16-pixel wide row for four 2-bit shades, for two alternating dither rows.
for(let parity=0;parity<2;parity++){let lo=Buffer.alloc(256),hi=Buffer.alloc(256);for(let c=0;c<256;c++){let v=0;for(let k=0;k<4;k++){let s=(c>>(6-k*2))&3,pat=parity?[0,0b0000,0b0101,15][s]:[0,0b1010,0b1111,15][s];v=(v<<4)|pat}lo[c]=v>>8;hi[c]=v&255}fs.writeFileSync(path.join(out,`expand-${parity}-a.bin`),lo);fs.writeFileSync(path.join(out,`expand-${parity}-b.bin`),hi)}
// Small projected cube vertex table; Z80 still draws all edges at runtime.
let cube=[];for(let f=0;f<64;f++)for(let i=0;i<8;i++){let t=f*TAU/64,v=rot([0,1,2].map(k=>(i>>k&1)?1:-1),t,t*.5),d=4+v[2],scale=99+12*Math.sin(t*2);cube.push(Math.round(128+v[0]*scale/d+8*Math.sin(t)),Math.round(96+v[1]*scale/d+6*Math.cos(t)))}fs.writeFileSync(path.join(out,'cube.bin'),Buffer.from(cube));
let hv=[];for(let f=0;f<32;f++){let t=f*TAU/32;for(let i=0;i<16;i++){let v=[0,1,2,3].map(k=>(i>>k&1)?1:-1),X=v[0]*Math.cos(t)-v[3]*Math.sin(t),w=v[3]*Math.cos(t)+v[0]*Math.sin(t);v[0]=X;let q=1.9/(3-w);v=rot(v.slice(0,3).map(x=>x*q),t*.5,.45);let d=3.6-v[2];hv.push(Math.round(128+v[0]*116/d),Math.round(96+v[1]*116/d))}}fs.writeFileSync(path.join(out,'hyper.bin'),Buffer.from(hv));
const matrix=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];let ramps=[];for(let lev=0;lev<16;lev++)for(let y=0;y<8;y++){let byte=0;for(let x=0;x<8;x++)if(matrix[(y&3)*4+(x&3)]<=lev)byte|=128>>x;ramps.push(byte)}fs.writeFileSync(path.join(out,'ramps.bin'),Buffer.from(ramps));
fs.writeFileSync(path.join(dir,'out','assets.json'),JSON.stringify({framesPerEffect:{metaballs:18,fractal:12,landscape:12,tesseract:'32 native vector poses',portals:12,chrome:12},modernRawBytes:report.length*640,modernPackedBytes:report.reduce((s,r)=>s+r.bytes,0),frames:report},null,2));console.log('Modern animations:',report.reduce((s,r)=>s+r.bytes,0),'bytes');
module.exports={compress,decompress,W,H};
